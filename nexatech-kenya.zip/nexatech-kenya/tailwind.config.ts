import type { Config } from 'tailwindcss';

const config: Config = {
  darkMode: 'class',
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      // ─── Color Palette ─────────────────────────────────────
      colors: {
        // Core dark backgrounds
        'nt-black':  '#000000',
        'nt-bg1':    '#080a0f',   // page background
        'nt-bg2':    '#0d1117',   // section alternate
        'nt-bg3':    '#111827',   // card background
        'nt-bg4':    '#1a2332',   // elevated card

        // Brand accent
        'nt-blue':   '#1e90ff',   // primary accent
        'nt-blue2':  '#0066cc',   // darker blue
        'nt-cyan':   '#00d4ff',   // neon highlight
        'nt-cyan2':  '#00b8d9',   // deeper cyan
        'nt-purple': '#7c3aed',   // secondary accent

        // Status
        'nt-neon':   '#39ff14',   // success/online
        'nt-red':    '#ff3366',   // danger/wishlist
        'nt-amber':  '#fbbf24',   // warning/stars

        // Text
        'nt-text1':  '#f0f4ff',   // primary text
        'nt-text2':  '#94a3b8',   // secondary text
        'nt-text3':  '#64748b',   // muted/placeholder
      },

      // ─── Typography ────────────────────────────────────────
      fontFamily: {
        sans:    ['Inter', 'system-ui', 'sans-serif'],
        display: ['Space Grotesk', 'Inter', 'sans-serif'],
        mono:    ['JetBrains Mono', 'Fira Code', 'monospace'],
      },
      fontSize: {
        'display-xl': ['clamp(3rem, 6vw, 5rem)',     { lineHeight: '1.05', fontWeight: '800' }],
        'display-lg': ['clamp(2.25rem, 4vw, 3.5rem)', { lineHeight: '1.1',  fontWeight: '700' }],
        'display-md': ['clamp(1.75rem, 3vw, 2.5rem)', { lineHeight: '1.15', fontWeight: '700' }],
      },

      // ─── Spacing ───────────────────────────────────────────
      spacing: {
        '18':  '4.5rem',
        '22':  '5.5rem',
        '26':  '6.5rem',
        '30':  '7.5rem',
        '128': '32rem',
        '144': '36rem',
      },

      // ─── Border Radius ─────────────────────────────────────
      borderRadius: {
        'xl2': '1rem',
        'xl3': '1.25rem',
        'xl4': '1.5rem',
        'xl5': '2rem',
      },

      // ─── Box Shadows ───────────────────────────────────────
      boxShadow: {
        'blue-sm':  '0 4px 24px rgba(30,144,255,0.15)',
        'blue-md':  '0 8px 40px rgba(30,144,255,0.25)',
        'blue-lg':  '0 16px 60px rgba(30,144,255,0.35)',
        'cyan-sm':  '0 4px 24px rgba(0,212,255,0.15)',
        'cyan-md':  '0 8px 40px rgba(0,212,255,0.25)',
        'glass':    '0 4px 32px rgba(0,0,0,0.4), inset 0 1px 0 rgba(255,255,255,0.06)',
        'card':     '0 2px 16px rgba(0,0,0,0.3), 0 0 0 1px rgba(255,255,255,0.06)',
        'neon-btn': '0 0 20px rgba(30,144,255,0.4), 0 0 40px rgba(30,144,255,0.2)',
      },

      // ─── Backgrounds / Gradients ───────────────────────────
      backgroundImage: {
        // Brand gradients
        'grad-blue':    'linear-gradient(135deg, #1e90ff, #00d4ff)',
        'grad-purple':  'linear-gradient(135deg, #7c3aed, #1e90ff)',
        'grad-dark':    'linear-gradient(135deg, #0d1117, #111827)',
        'grad-hero':    'radial-gradient(ellipse at 60% 50%, rgba(30,144,255,0.12) 0%, transparent 60%), radial-gradient(ellipse at 20% 80%, rgba(124,58,237,0.10) 0%, transparent 50%)',
        'grad-card':    'linear-gradient(180deg, rgba(255,255,255,0.04) 0%, rgba(255,255,255,0) 100%)',

        // Glassmorphism
        'glass':        'rgba(255,255,255,0.04)',
        'glass-hover':  'rgba(255,255,255,0.08)',
        'glass-border': 'rgba(255,255,255,0.08)',
      },

      // ─── Animations ────────────────────────────────────────
      keyframes: {
        'fade-up': {
          '0%':   { opacity: '0', transform: 'translateY(24px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'fade-in': {
          '0%':   { opacity: '0' },
          '100%': { opacity: '1' },
        },
        'slide-in-right': {
          '0%':   { opacity: '0', transform: 'translateX(20px)' },
          '100%': { opacity: '1', transform: 'translateX(0)' },
        },
        'float': {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%':      { transform: 'translateY(-12px)' },
        },
        'pulse-ring': {
          '0%':   { transform: 'scale(0.95)', opacity: '1' },
          '100%': { transform: 'scale(1.4)',  opacity: '0' },
        },
        'spin-slow': {
          'from': { transform: 'rotate(0deg)' },
          'to':   { transform: 'rotate(360deg)' },
        },
        'spin-slower': {
          'from': { transform: 'rotate(360deg)' },
          'to':   { transform: 'rotate(0deg)' },
        },
        'shimmer': {
          '0%':   { backgroundPosition: '-1000px 0' },
          '100%': { backgroundPosition: '1000px 0' },
        },
        'particle-rise': {
          '0%':   { transform: 'translateY(100vh) scale(0)', opacity: '0' },
          '10%':  { opacity: '1' },
          '90%':  { opacity: '0.3' },
          '100%': { transform: 'translateY(-10vh) scale(1)', opacity: '0' },
        },
        'cart-bounce': {
          '0%, 100%': { transform: 'scale(1)' },
          '50%':      { transform: 'scale(1.3)' },
        },
        'gradient-shift': {
          '0%, 100%': { backgroundPosition: '0% 50%' },
          '50%':      { backgroundPosition: '100% 50%' },
        },
      },
      animation: {
        'fade-up':         'fade-up 0.6s ease forwards',
        'fade-up-slow':    'fade-up 0.9s ease forwards',
        'fade-in':         'fade-in 0.4s ease forwards',
        'slide-in-right':  'slide-in-right 0.4s ease forwards',
        'float':           'float 4s ease-in-out infinite',
        'float-slow':      'float 6s ease-in-out infinite',
        'pulse-ring':      'pulse-ring 2s cubic-bezier(0.4,0,0.6,1) infinite',
        'spin-slow':       'spin-slow 20s linear infinite',
        'spin-slower':     'spin-slower 30s linear infinite',
        'shimmer':         'shimmer 2s linear infinite',
        'particle-rise':   'particle-rise 12s linear infinite',
        'cart-bounce':     'cart-bounce 0.4s ease',
        'gradient-shift':  'gradient-shift 6s ease infinite',
      },

      // ─── Transitions ───────────────────────────────────────
      transitionTimingFunction: {
        'spring':   'cubic-bezier(0.175, 0.885, 0.32, 1.275)',
        'smooth':   'cubic-bezier(0.4, 0, 0.2, 1)',
        'ease-out-expo': 'cubic-bezier(0.19, 1, 0.22, 1)',
      },

      // ─── Backdrop Blur ─────────────────────────────────────
      backdropBlur: {
        'xs':   '2px',
        'sm':   '8px',
        'md':   '16px',
        'lg':   '24px',
        'xl':   '40px',
        '2xl':  '64px',
      },

      // ─── Z-Index ───────────────────────────────────────────
      zIndex: {
        'nav':     '100',
        'modal':   '200',
        'toast':   '300',
        'tooltip': '400',
      },

      // ─── Max Width ─────────────────────────────────────────
      maxWidth: {
        'site': '1200px',
        '8xl':  '88rem',
      },

      // ─── Screens ───────────────────────────────────────────
      screens: {
        'xs': '390px',
      },
    },
  },
  plugins: [
    // Plugin for glassmorphism utilities
    function({ addUtilities }: { addUtilities: Function }) {
      addUtilities({
        '.glass': {
          background: 'rgba(255, 255, 255, 0.04)',
          backdropFilter: 'blur(16px)',
          '-webkit-backdrop-filter': 'blur(16px)',
          border: '1px solid rgba(255, 255, 255, 0.08)',
        },
        '.glass-hover': {
          background: 'rgba(255, 255, 255, 0.08)',
        },
        '.glass-blue': {
          background: 'rgba(30, 144, 255, 0.08)',
          backdropFilter: 'blur(16px)',
          '-webkit-backdrop-filter': 'blur(16px)',
          border: '1px solid rgba(30, 144, 255, 0.2)',
        },
        '.text-gradient-blue': {
          background: 'linear-gradient(135deg, #1e90ff, #00d4ff)',
          '-webkit-background-clip': 'text',
          '-webkit-text-fill-color': 'transparent',
          backgroundClip: 'text',
        },
        '.text-gradient-purple': {
          background: 'linear-gradient(135deg, #7c3aed, #1e90ff)',
          '-webkit-background-clip': 'text',
          '-webkit-text-fill-color': 'transparent',
          backgroundClip: 'text',
        },
        '.border-glass': {
          border: '1px solid rgba(255, 255, 255, 0.08)',
        },
        '.border-blue-glow': {
          border: '1px solid rgba(30, 144, 255, 0.3)',
        },
        '.btn-glow': {
          boxShadow: '0 0 20px rgba(30, 144, 255, 0.4), 0 0 40px rgba(30, 144, 255, 0.2)',
        },
        '.scrollbar-thin': {
          scrollbarWidth: 'thin',
          scrollbarColor: '#1e90ff #0d1117',
        },
        '.will-change-transform': {
          willChange: 'transform',
        },
      });
    },
  ],
};

export default config;
