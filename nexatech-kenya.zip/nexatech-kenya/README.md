# NexaTech Kenya — Premium Electronics Marketplace

> Kenya's #1 premium tech marketplace. Built with Next.js 15, React 19, Framer Motion, GSAP, and Three.js.

![NexaTech Kenya](https://nexatech.co.ke/og-image.jpg)

---

## ✨ Features

| Feature | Details |
|---------|---------|
| 🎨 **Premium Dark Theme** | Black bg, electric blue & cyan accents, glassmorphism cards |
| 🚀 **Hero Section** | Three.js floating orb, particle system, GSAP entrance animations |
| 🗂️ **7 Categories** | Laptops, Gaming, Monitors, Accessories, Networking, Printers, Components |
| 🛍️ **Product Grid** | Quick-view modal, add-to-cart bounce, wishlist heart pop, compare tool |
| 🤖 **AI Laptop Finder** | 3-step wizard — use case → budget → recommendations |
| ⚖️ **Comparison Tool** | Animated side-by-side spec table for up to 3 products |
| 🖥️ **Build Your Setup** | Click-to-add accessory builder with live price total |
| ⭐ **Customer Reviews** | Video cards, star ratings, verified badges, helpful votes |
| 💳 **Checkout** | M-Pesa STK Push, Visa, Mastercard, Bank Transfer |
| 📱 **Mobile-First** | Full responsive, optimised touch targets, slide-in mobile nav |
| ⚡ **Animations** | Framer Motion, GSAP ScrollTrigger, parallax, magnetic buttons |
| 🌐 **API Routes** | Products, Orders, M-Pesa STK Push, M-Pesa Callback |

---

## 🛠️ Tech Stack

```
Next.js 15 (App Router)   React 19         TypeScript 5
Tailwind CSS 3            Framer Motion 11  GSAP 3 + ScrollTrigger
Three.js + R3F            Zustand 5        react-hot-toast
Lenis (smooth scroll)     Lucide React     Radix UI primitives
```

---

## 📁 Project Structure

```
nexatech-kenya/
├── src/
│   ├── app/
│   │   ├── api/
│   │   │   ├── mpesa/
│   │   │   │   ├── stkpush/route.ts   # M-Pesa STK Push
│   │   │   │   └── callback/route.ts  # M-Pesa payment callback
│   │   │   ├── products/route.ts      # Products API (filter/sort/paginate)
│   │   │   └── orders/route.ts        # Create & retrieve orders
│   │   ├── layout.tsx                 # Root layout (fonts, metadata)
│   │   └── page.tsx                   # Home page (assembles all sections)
│   │
│   ├── components/
│   │   ├── layout/
│   │   │   ├── Navbar.tsx             # Sticky nav, mobile menu, floating cart
│   │   │   ├── Footer.tsx             # Full footer with newsletter
│   │   │   └── Providers.tsx          # Framer Motion, Lenis, Toast providers
│   │   ├── sections/
│   │   │   ├── HeroSection.tsx        # Three.js + GSAP hero
│   │   │   ├── TrustedBrands.tsx      # Brand logo strip
│   │   │   ├── CategoriesSection.tsx  # Category cards
│   │   │   ├── PromoBanner.tsx        # Promo code banner
│   │   │   ├── ProductsSection.tsx    # Tabbed products grid + quick-view modal
│   │   │   ├── AIFinderSection.tsx    # 3-step AI laptop finder wizard
│   │   │   ├── ComparisonSection.tsx  # Side-by-side comparison table
│   │   │   ├── BuildSetupSection.tsx  # Drag-to-build workspace
│   │   │   ├── ReviewsSection.tsx     # Customer reviews with video
│   │   │   └── CheckoutSection.tsx    # Full checkout with payment methods
│   │   ├── products/
│   │   │   └── ProductCard.tsx        # Animated product card
│   │   ├── ui/
│   │   │   ├── Button.tsx             # CVA button with variants
│   │   │   ├── Badge.tsx              # Status badge
│   │   │   ├── Skeleton.tsx           # Loading skeleton
│   │   │   └── Section.tsx            # SectionHeader, Reveal, GlassCard
│   │   └── index.ts                   # Barrel exports
│   │
│   ├── data/
│   │   └── index.ts                   # Products, categories, reviews, sample data
│   ├── hooks/
│   │   └── index.ts                   # useCart, useWishlist, useScrollReveal, etc.
│   ├── lib/
│   │   ├── utils.ts                   # cn(), formatKES(), etc.
│   │   └── animations.ts             # GSAP helpers, Framer Motion variants
│   ├── store/
│   │   └── index.ts                   # Zustand store (cart, wishlist, compare, etc.)
│   ├── styles/
│   │   └── globals.css               # CSS variables, base styles, animations
│   └── types/
│       └── index.ts                   # Full TypeScript types
│
├── tailwind.config.ts                 # Custom Tailwind tokens
├── next.config.ts                     # Next.js config
├── tsconfig.json
├── package.json
└── .env.example                       # Environment variables template
```

---

## 🚀 Getting Started

### 1. Clone & Install

```bash
git clone https://github.com/nexatech-ke/nexatech-kenya.git
cd nexatech-kenya
npm install
```

### 2. Environment Variables

```bash
cp .env.example .env.local
# Fill in your M-Pesa, Stripe, Supabase credentials
```

### 3. Run Development Server

```bash
npm run dev
# → http://localhost:3000
```

### 4. Build for Production

```bash
npm run build
npm start
```

---

## 💳 Payment Integration

### M-Pesa (Safaricom Daraja API)

1. Register at [developer.safaricom.co.ke](https://developer.safaricom.co.ke)
2. Create an app → get **Consumer Key** and **Consumer Secret**
3. Get your **Lipa Na M-Pesa Passkey** from the portal
4. Update `.env.local` with your credentials
5. Set `MPESA_CALLBACK_URL` to your public URL (use ngrok for local dev)

```bash
# Test locally with ngrok
ngrok http 3000
# Set MPESA_CALLBACK_URL=https://abc123.ngrok.io/api/mpesa/callback
```

### Stripe (Visa / Mastercard)

```bash
# Install Stripe
npm install @stripe/stripe-js @stripe/react-stripe-js stripe
```

Add your keys to `.env.local` and update `CheckoutSection.tsx` to call `/api/payments/stripe`.

---

## 🎨 Design Tokens

```css
--nt-blue:   #1e90ff   /* Primary accent */
--nt-cyan:   #00d4ff   /* Neon highlight */
--nt-purple: #7c3aed   /* Secondary accent */
--nt-neon:   #39ff14   /* Success/online */
--nt-red:    #ff3366   /* Danger/wishlist */
--nt-bg1:    #080a0f   /* Page background */
--nt-bg2:    #0d1117   /* Alt section bg */
--nt-bg3:    #111827   /* Card background */
```

---

## 📦 Adding Products

Edit `src/data/index.ts` and add to the `PRODUCTS` array:

```ts
{
  id: 13,
  brand: 'Apple',
  name: 'MacBook Air M3 15"',
  slug: 'macbook-air-m3-15',
  shortSpecs: 'Apple M3 · 8GB · 256GB SSD',
  specs: [...],
  price: 135000,
  icon: '💻',
  category: 'laptops',
  badge: 'New',
  rating: 5,
  reviewCount: 0,
  inStock: true,
  sku: 'APL-MBA-M3-15-256',
  tags: ['apple', 'macbook', 'thin', 'lightweight'],
}
```

---

## 🚢 Deployment

### Vercel (Recommended)

```bash
npm install -g vercel
vercel --prod
```

### Docker

```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY . .
RUN npm ci && npm run build
EXPOSE 3000
CMD ["npm", "start"]
```

---

## 📄 License

MIT © 2025 NexaTech Kenya Ltd.
