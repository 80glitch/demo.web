'use client';

import { create } from 'zustand';
import { persist, devtools } from 'zustand/middleware';
import type { CartItem, Product, SetupItem, Toast, ToastType, UseCase } from '@/types';

// ─── TYPES ───────────────────────────────────────────────────
interface CartSlice {
  cartItems: CartItem[];
  addToCart: (product: Product, qty?: number) => void;
  removeFromCart: (productId: number) => void;
  updateQty: (productId: number, qty: number) => void;
  clearCart: () => void;
  cartCount: () => number;
  cartTotal: () => number;
  cartVat: () => number;
  cartGrandTotal: () => number;
}

interface WishlistSlice {
  wishlistIds: number[];
  toggleWishlist: (productId: number) => void;
  isWishlisted: (productId: number) => boolean;
}

interface CompareSlice {
  compareNames: string[];
  addToCompare: (name: string) => void;
  removeFromCompare: (name: string) => void;
  clearCompare: () => void;
}

interface SetupSlice {
  setupItems: SetupItem[];
  addToSetup: (item: Omit<SetupItem, 'uid'>) => void;
  removeFromSetup: (uid: string) => void;
  clearSetup: () => void;
  setupTotal: () => number;
}

interface FinderSlice {
  finderUseCases: UseCase[];
  finderBudget: number;
  finderStep: 1 | 2 | 3;
  setFinderUseCases: (useCases: UseCase[]) => void;
  setFinderBudget: (budget: number) => void;
  setFinderStep: (step: 1 | 2 | 3) => void;
  resetFinder: () => void;
}

interface UISlice {
  isModalOpen: boolean;
  modalProductId: number | null;
  isMobileMenuOpen: boolean;
  activeProductTab: string;
  toasts: Toast[];
  openModal: (productId: number) => void;
  closeModal: () => void;
  setMobileMenuOpen: (open: boolean) => void;
  setActiveProductTab: (tab: string) => void;
  addToast: (message: string, icon?: string, type?: ToastType, duration?: number) => void;
  removeToast: (id: string) => void;
}

type StoreState = CartSlice & WishlistSlice & CompareSlice & SetupSlice & FinderSlice & UISlice;

// ─── STORE ───────────────────────────────────────────────────
export const useStore = create<StoreState>()(
  devtools(
    persist(
      (set, get) => ({

        // ── Cart ──────────────────────────────────────────────
        cartItems: [],

        addToCart: (product, qty = 1) => set(state => {
          const existing = state.cartItems.find(i => i.product.id === product.id);
          return {
            cartItems: existing
              ? state.cartItems.map(i =>
                  i.product.id === product.id ? { ...i, qty: i.qty + qty } : i
                )
              : [...state.cartItems, { product, qty }],
          };
        }),

        removeFromCart: (productId) => set(state => ({
          cartItems: state.cartItems.filter(i => i.product.id !== productId),
        })),

        updateQty: (productId, qty) => set(state => ({
          cartItems: qty <= 0
            ? state.cartItems.filter(i => i.product.id !== productId)
            : state.cartItems.map(i => i.product.id === productId ? { ...i, qty } : i),
        })),

        clearCart: () => set({ cartItems: [] }),

        cartCount: () => get().cartItems.reduce((s, i) => s + i.qty, 0),
        cartTotal: () => get().cartItems.reduce((s, i) => s + i.product.price * i.qty, 0),
        cartVat: () => Math.round(get().cartTotal() * 0.16),
        cartGrandTotal: () => Math.round(get().cartTotal() * 1.16),

        // ── Wishlist ──────────────────────────────────────────
        wishlistIds: [],

        toggleWishlist: (productId) => set(state => ({
          wishlistIds: state.wishlistIds.includes(productId)
            ? state.wishlistIds.filter(id => id !== productId)
            : [...state.wishlistIds, productId],
        })),

        isWishlisted: (productId) => get().wishlistIds.includes(productId),

        // ── Compare ───────────────────────────────────────────
        compareNames: [],

        addToCompare: (name) => set(state => {
          if (state.compareNames.includes(name)) return state;
          const next = [...state.compareNames, name];
          return { compareNames: next.length > 3 ? next.slice(-3) : next };
        }),

        removeFromCompare: (name) => set(state => ({
          compareNames: state.compareNames.filter(n => n !== name),
        })),

        clearCompare: () => set({ compareNames: [] }),

        // ── Setup Builder ────────────────────────────────────
        setupItems: [],

        addToSetup: (item) => set(state => ({
          setupItems: [...state.setupItems, { ...item, uid: `${Date.now()}-${Math.random()}` }],
        })),

        removeFromSetup: (uid) => set(state => ({
          setupItems: state.setupItems.filter(i => i.uid !== uid),
        })),

        clearSetup: () => set({ setupItems: [] }),

        setupTotal: () => get().setupItems.reduce((s, i) => s + i.price, 0),

        // ── Finder ────────────────────────────────────────────
        finderUseCases: [],
        finderBudget: 100000,
        finderStep: 1,

        setFinderUseCases: (useCases) => set({ finderUseCases: useCases }),
        setFinderBudget: (budget) => set({ finderBudget: budget }),
        setFinderStep: (step) => set({ finderStep: step }),
        resetFinder: () => set({ finderUseCases: [], finderBudget: 100000, finderStep: 1 }),

        // ── UI ────────────────────────────────────────────────
        isModalOpen: false,
        modalProductId: null,
        isMobileMenuOpen: false,
        activeProductTab: 'all',
        toasts: [],

        openModal: (productId) => set({ isModalOpen: true, modalProductId: productId }),
        closeModal: () => set({ isModalOpen: false, modalProductId: null }),
        setMobileMenuOpen: (open) => set({ isMobileMenuOpen: open }),
        setActiveProductTab: (tab) => set({ activeProductTab: tab }),

        addToast: (message, icon = '✅', type = 'success', duration = 3000) => {
          const id = `toast-${Date.now()}-${Math.random().toString(36).slice(2)}`;
          set(state => ({ toasts: [...state.toasts, { id, message, icon, type, duration }] }));
          setTimeout(() => {
            set(state => ({ toasts: state.toasts.filter(t => t.id !== id) }));
          }, duration);
        },

        removeToast: (id) => set(state => ({
          toasts: state.toasts.filter(t => t.id !== id),
        })),
      }),

      {
        name: 'nexatech-store',
        // Only persist cart, wishlist, compare — not transient UI state
        partialize: (state) => ({
          cartItems:   state.cartItems,
          wishlistIds: state.wishlistIds,
          compareNames: state.compareNames,
        }),
      }
    ),
    { name: 'NexaTech Store' }
  )
);

// ─── CONVENIENCE SELECTORS ───────────────────────────────────
export const selectCartCount    = (s: StoreState) => s.cartCount();
export const selectCartTotal    = (s: StoreState) => s.cartTotal();
export const selectCartGrand    = (s: StoreState) => s.cartGrandTotal();
export const selectSetupTotal   = (s: StoreState) => s.setupTotal();
export const selectIsWishlisted = (id: number) => (s: StoreState) => s.isWishlisted(id);
