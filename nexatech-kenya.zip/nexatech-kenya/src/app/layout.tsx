import type { Metadata, Viewport } from 'next';
import { Inter, Space_Grotesk, JetBrains_Mono } from 'next/font/google';
import '@/styles/globals.css';
import { Providers } from '@/components/layout/Providers';

// ─── Fonts ────────────────────────────────────────────────────
const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
  weight: ['300', '400', '500', '600', '700', '800', '900'],
});

const spaceGrotesk = Space_Grotesk({
  subsets: ['latin'],
  variable: '--font-space-grotesk',
  display: 'swap',
  weight: ['400', '500', '600', '700'],
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-jetbrains',
  display: 'swap',
  weight: ['400', '500'],
});

// ─── Metadata ─────────────────────────────────────────────────
export const metadata: Metadata = {
  title: {
    default: 'NexaTech Kenya — Premium Electronics Marketplace',
    template: '%s | NexaTech Kenya',
  },
  description:
    'Kenya\'s #1 premium tech marketplace. Shop laptops, gaming rigs, monitors, networking, printers and accessories. M-Pesa accepted. 2hr delivery in Nairobi.',
  keywords: [
    'laptops Kenya', 'gaming laptops Nairobi', 'MacBook Kenya', 'Dell Kenya',
    'electronics Kenya', 'tech store Nairobi', 'buy laptop online Kenya',
    'M-Pesa electronics', 'monitors Kenya', 'computer accessories Nairobi',
    'NexaTech Kenya', 'Jumia alternative', 'Kilimall alternative',
  ],
  authors: [{ name: 'NexaTech Kenya Ltd' }],
  creator: 'NexaTech Kenya',
  publisher: 'NexaTech Kenya Ltd',
  metadataBase: new URL('https://nexatech.co.ke'),
  openGraph: {
    type: 'website',
    locale: 'en_KE',
    url: 'https://nexatech.co.ke',
    siteName: 'NexaTech Kenya',
    title: 'NexaTech Kenya — Premium Electronics Marketplace',
    description: 'Kenya\'s #1 premium tech marketplace. Shop laptops, gaming rigs, monitors and accessories. M-Pesa accepted.',
    images: [
      {
        url: '/og-image.jpg',
        width: 1200,
        height: 630,
        alt: 'NexaTech Kenya — Premium Electronics',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'NexaTech Kenya — Premium Electronics Marketplace',
    description: 'Kenya\'s #1 premium tech marketplace. M-Pesa accepted. 2hr delivery in Nairobi.',
    images: ['/og-image.jpg'],
    creator: '@nexatechkenya',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  icons: {
    icon: '/favicon.ico',
    shortcut: '/favicon-16x16.png',
    apple: '/apple-touch-icon.png',
  },
  manifest: '/site.webmanifest',
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  themeColor: '#080a0f',
};

// ─── Layout ───────────────────────────────────────────────────
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="en"
      className={`${inter.variable} ${spaceGrotesk.variable} ${jetbrainsMono.variable}`}
      suppressHydrationWarning
    >
      <body className="font-sans bg-nt-bg1 text-nt-text1 overflow-x-hidden">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
