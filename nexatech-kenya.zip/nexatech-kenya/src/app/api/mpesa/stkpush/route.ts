import { NextRequest, NextResponse } from 'next/server';

// ─── M-Pesa STK Push ─────────────────────────────────────────
// Safaricom Daraja API v1 integration
// Docs: https://developer.safaricom.co.ke/Documentation

const MPESA_ENV     = process.env.MPESA_ENV || 'sandbox';
const BASE_URL      = MPESA_ENV === 'production'
  ? 'https://api.safaricom.co.ke'
  : 'https://sandbox.safaricom.co.ke';

async function getAccessToken(): Promise<string> {
  const key    = process.env.MPESA_CONSUMER_KEY!;
  const secret = process.env.MPESA_CONSUMER_SECRET!;
  const credentials = Buffer.from(`${key}:${secret}`).toString('base64');

  const res = await fetch(`${BASE_URL}/oauth/v1/generate?grant_type=client_credentials`, {
    headers: { Authorization: `Basic ${credentials}` },
    cache: 'no-store',
  });

  if (!res.ok) throw new Error('Failed to get M-Pesa access token');
  const data = await res.json();
  return data.access_token;
}

function generatePassword(shortcode: string, passkey: string, timestamp: string): string {
  const raw = `${shortcode}${passkey}${timestamp}`;
  return Buffer.from(raw).toString('base64');
}

function formatTimestamp(): string {
  return new Date()
    .toISOString()
    .replace(/[-:T.Z]/g, '')
    .slice(0, 14);
}

function formatPhone(phone: string): string {
  // Normalise to 254XXXXXXXXX format
  let p = phone.replace(/\s+/g, '').replace(/^\+/, '');
  if (p.startsWith('0'))   p = `254${p.slice(1)}`;
  if (p.startsWith('254')) return p;
  throw new Error('Invalid Kenyan phone number');
}

// ─── POST /api/mpesa/stkpush ─────────────────────────────────
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { phone, amount, orderId } = body as {
      phone: string;
      amount: number;
      orderId: string;
    };

    if (!phone || !amount || !orderId) {
      return NextResponse.json({ error: 'phone, amount, and orderId are required' }, { status: 400 });
    }

    const formattedPhone  = formatPhone(phone);
    const timestamp       = formatTimestamp();
    const shortcode       = process.env.MPESA_SHORTCODE!;
    const passkey         = process.env.MPESA_PASSKEY!;
    const password        = generatePassword(shortcode, passkey, timestamp);
    const callbackUrl     = process.env.MPESA_CALLBACK_URL!;
    const accessToken     = await getAccessToken();

    const payload = {
      BusinessShortCode: shortcode,
      Password:          password,
      Timestamp:         timestamp,
      TransactionType:   'CustomerPayBillOnline',
      Amount:            Math.ceil(amount),
      PartyA:            formattedPhone,
      PartyB:            shortcode,
      PhoneNumber:       formattedPhone,
      CallBackURL:       callbackUrl,
      AccountReference:  orderId,
      TransactionDesc:   `NexaTech Order ${orderId}`,
    };

    const stkRes = await fetch(`${BASE_URL}/mpesa/stkpush/v1/processrequest`, {
      method: 'POST',
      headers: {
        'Content-Type':  'application/json',
        Authorization:   `Bearer ${accessToken}`,
      },
      body: JSON.stringify(payload),
    });

    const stkData = await stkRes.json();

    if (!stkRes.ok || stkData.ResponseCode !== '0') {
      return NextResponse.json(
        { error: stkData.errorMessage || 'STK push failed' },
        { status: 500 },
      );
    }

    return NextResponse.json({
      success:          true,
      checkoutRequestId: stkData.CheckoutRequestID,
      merchantRequestId: stkData.MerchantRequestID,
      message:          'STK push sent. Check your phone.',
    });

  } catch (err) {
    console.error('[mpesa/stkpush]', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
