import { NextRequest, NextResponse } from 'next/server';

// ─── POST /api/mpesa/callback ─────────────────────────────────
// Safaricom calls this URL after the customer completes/cancels the payment.
// In production: verify the payload, update your DB, and send confirmation email/SMS.

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    const stkCallback = body?.Body?.stkCallback;
    if (!stkCallback) {
      return NextResponse.json({ ResultCode: 1, ResultDesc: 'Invalid payload' });
    }

    const { MerchantRequestID, CheckoutRequestID, ResultCode, ResultDesc, CallbackMetadata } = stkCallback;

    // ── Payment succeeded ──
    if (ResultCode === 0) {
      const items: Record<string, unknown> = {};
      for (const item of CallbackMetadata?.Item ?? []) {
        items[item.Name] = item.Value;
      }

      const paymentData = {
        merchantRequestId:  MerchantRequestID,
        checkoutRequestId:  CheckoutRequestID,
        amount:             items.Amount,
        mpesaReceiptNumber: items.MpesaReceiptNumber,
        transactionDate:    items.TransactionDate,
        phoneNumber:        items.PhoneNumber,
      };

      console.log('[M-Pesa] Payment SUCCESS:', paymentData);

      // TODO in production:
      // 1. Verify orderId from AccountReference
      // 2. Update order status in DB to "paid"
      // 3. Send confirmation SMS via Africa's Talking
      // 4. Send confirmation email via Resend
      // 5. Trigger fulfilment / warehouse notification

    } else {
      // ── Payment failed / cancelled ──
      console.warn('[M-Pesa] Payment FAILED:', { ResultCode, ResultDesc, CheckoutRequestID });

      // TODO: Update order status to "payment_failed", notify customer
    }

    // Always respond 200 to Safaricom — they retry on non-200
    return NextResponse.json({ ResultCode: 0, ResultDesc: 'Accepted' });

  } catch (err) {
    console.error('[mpesa/callback]', err);
    return NextResponse.json({ ResultCode: 0, ResultDesc: 'Accepted' });
  }
}
