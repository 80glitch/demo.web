import { NextRequest, NextResponse } from 'next/server';
import { PRODUCTS } from '@/data';
import type { ProductCategory } from '@/types';

// ─── GET /api/products ────────────────────────────────────────
// Query params:
//   ?category=laptops         filter by category
//   ?q=macbook                search by name/brand
//   ?minPrice=50000           min price filter (KES)
//   ?maxPrice=200000          max price filter (KES)
//   ?sort=price_asc|price_desc|rating|newest
//   ?page=1&limit=12          pagination
//   ?badge=New|Hot|Sale       filter by badge
//   ?inStock=true             only in-stock items

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = req.nextUrl;

    const category = searchParams.get('category') as ProductCategory | null;
    const q        = searchParams.get('q')?.toLowerCase();
    const minPrice = searchParams.get('minPrice') ? Number(searchParams.get('minPrice')) : null;
    const maxPrice = searchParams.get('maxPrice') ? Number(searchParams.get('maxPrice')) : null;
    const sort     = searchParams.get('sort') ?? 'newest';
    const badge    = searchParams.get('badge');
    const inStock  = searchParams.get('inStock') === 'true';
    const page     = Math.max(1, Number(searchParams.get('page') ?? 1));
    const limit    = Math.min(50, Math.max(1, Number(searchParams.get('limit') ?? 12)));

    let results = [...PRODUCTS];

    // ── Filter ────────────────────────────────────────────────
    if (category)  results = results.filter(p => p.category === category);
    if (badge)     results = results.filter(p => p.badge === badge);
    if (inStock)   results = results.filter(p => p.inStock);
    if (minPrice !== null) results = results.filter(p => p.price >= minPrice);
    if (maxPrice !== null) results = results.filter(p => p.price <= maxPrice);
    if (q) {
      results = results.filter(p =>
        p.name.toLowerCase().includes(q)        ||
        p.brand.toLowerCase().includes(q)       ||
        p.shortSpecs.toLowerCase().includes(q)  ||
        p.tags.some(t => t.includes(q)),
      );
    }

    // ── Sort ──────────────────────────────────────────────────
    switch (sort) {
      case 'price_asc':  results.sort((a, b) => a.price - b.price); break;
      case 'price_desc': results.sort((a, b) => b.price - a.price); break;
      case 'rating':     results.sort((a, b) => b.rating - a.rating || b.reviewCount - a.reviewCount); break;
      case 'newest':     results.sort((a, b) => b.id - a.id); break;
      case 'popular':    results.sort((a, b) => b.reviewCount - a.reviewCount); break;
    }

    // ── Paginate ──────────────────────────────────────────────
    const total  = results.length;
    const pages  = Math.ceil(total / limit);
    const offset = (page - 1) * limit;
    const data   = results.slice(offset, offset + limit);

    return NextResponse.json({
      data,
      meta: {
        total,
        page,
        limit,
        pages,
        hasNext: page < pages,
        hasPrev: page > 1,
      },
    }, {
      headers: {
        'Cache-Control': 'public, s-maxage=60, stale-while-revalidate=120',
      },
    });

  } catch (err) {
    console.error('[api/products]', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
