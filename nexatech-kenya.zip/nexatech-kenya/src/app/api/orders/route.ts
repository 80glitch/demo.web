import { NextRequest, NextResponse } from 'next/server';
import { uid } from '@/lib/utils';

// In production, replace with real DB queries (Supabase/Prisma).
// This is an in-memory mock for development.
const ORDERS_STORE: Record<string, object> = {};

// ─── POST /api/orders — create order ─────────────────────────
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { items, delivery, payment, subtotal, vat, deliveryFee = 0 } = body;

    if (!items?.length || !delivery || !payment) {
      return NextResponse.json({ error: 'items, delivery, and payment are required' }, { status: 400 });
    }

    const orderId = `NXT-${Date.now()}-${uid().toUpperCase()}`;
    const order = {
      id:          orderId,
      items,
      delivery,
      payment:     { method: payment.method },   // never store raw card numbers
      subtotal,
      vat,
      deliveryFee,
      total:       subtotal + vat + deliveryFee,
      status:      'pending',
      createdAt:   new Date().toISOString(),
    };

    ORDERS_STORE[orderId] = order;

    // TODO in production:
    // - Persist to Supabase: await supabase.from('orders').insert(order)
    // - Trigger M-Pesa STK push if payment.method === 'mpesa'
    // - Send email confirmation via Resend
    // - Send SMS via Africa's Talking

    return NextResponse.json({ success: true, orderId, order }, { status: 201 });

  } catch (err) {
    console.error('[api/orders POST]', err);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

// ─── GET /api/orders?id=NXT-xxx — fetch order ────────────────
export async function GET(req: NextRequest) {
  const id    = req.nextUrl.searchParams.get('id');
  if (!id)    return NextResponse.json({ error: 'id is required' }, { status: 400 });

  const order = ORDERS_STORE[id];
  if (!order) return NextResponse.json({ error: 'Order not found' }, { status: 404 });

  return NextResponse.json({ order });
}
