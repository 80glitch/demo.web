import { Navbar }            from '@/components/layout/Navbar';
import { Footer }            from '@/components/layout/Footer';
import { HeroSection }       from '@/components/sections/HeroSection';
import { TrustedBrands }     from '@/components/sections/TrustedBrands';
import { CategoriesSection } from '@/components/sections/CategoriesSection';
import { PromoBanner }       from '@/components/sections/PromoBanner';
import { ProductsSection }   from '@/components/sections/ProductsSection';
import { AIFinderSection }   from '@/components/sections/AIFinderSection';
import { ComparisonSection } from '@/components/sections/ComparisonSection';
import { BuildSetupSection } from '@/components/sections/BuildSetupSection';
import { ReviewsSection }    from '@/components/sections/ReviewsSection';
import { CheckoutSection }   from '@/components/sections/CheckoutSection';

export default function HomePage() {
  return (
    <main>
      <Navbar />
      <HeroSection />
      <TrustedBrands />
      <CategoriesSection />
      <PromoBanner />
      <ProductsSection />
      <AIFinderSection />
      <ComparisonSection />
      <BuildSetupSection />
      <ReviewsSection />
      <CheckoutSection />
      <Footer />
    </main>
  );
}
