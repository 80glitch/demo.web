// ============================================================
// NexaTech Kenya – TypeScript Types
// ============================================================

export type ProductCategory =
  | 'laptops'
  | 'gaming'
  | 'monitors'
  | 'accessories'
  | 'networking'
  | 'printers'
  | 'components';

export type ProductBadge = 'New' | 'Hot' | 'Sale' | 'Limited' | null;

export type UseCase =
  | 'Programming'
  | 'Gaming'
  | 'School'
  | 'Business'
  | 'Design'
  | 'Video Editing';

export type PaymentMethod = 'mpesa' | 'visa' | 'mastercard' | 'bank';

// ─── Product ────────────────────────────────────────────────
export interface ProductSpec {
  label: string;
  value: string;
}

export interface Product {
  id: number;
  brand: string;
  name: string;
  slug: string;
  shortSpecs: string;        // "Intel i7 · 16GB · 512GB"
  specs: ProductSpec[];      // Full spec list
  price: number;             // KES
  oldPrice?: number;
  icon: string;              // emoji fallback
  imageUrl?: string;
  category: ProductCategory;
  badge: ProductBadge;
  rating: number;            // 1-5
  reviewCount: number;
  inStock: boolean;
  sku: string;
  tags: string[];
}

// ─── Cart ────────────────────────────────────────────────────
export interface CartItem {
  product: Product;
  qty: number;
}

export interface CartState {
  items: CartItem[];
  total: number;
  vat: number;
  grandTotal: number;
}

// ─── Compare ─────────────────────────────────────────────────
export interface CompareSpec {
  key: string;
  label: string;
}

export interface CompareProduct {
  id: number;
  name: string;
  icon: string;
  price: string;
  specs: Record<string, string>;
}

// ─── Setup Builder ───────────────────────────────────────────
export interface SetupAccessory {
  id: string;
  name: string;
  icon: string;
  price: number;
  category: string;
}

export interface SetupItem extends SetupAccessory {
  uid: string;
}

// ─── Review ──────────────────────────────────────────────────
export interface Review {
  id: number;
  author: string;
  initials: string;
  location: string;
  rating: number;
  body: string;
  productName: string;
  verified: boolean;
  hasVideo?: boolean;
  videoThumbnail?: string;
  date: string;
}

// ─── Category ────────────────────────────────────────────────
export interface Category {
  id: ProductCategory;
  name: string;
  icon: string;
  count: number;
  description: string;
}

// ─── AI Finder ───────────────────────────────────────────────
export interface FinderState {
  useCases: UseCase[];
  budget: number;
  step: 1 | 2 | 3;
  results: Product[];
}

// ─── Checkout ────────────────────────────────────────────────
export interface DeliveryAddress {
  firstName: string;
  lastName: string;
  phone: string;
  address: string;
  city: string;
  area: string;
  email?: string;
}

export interface MpesaPayment {
  method: 'mpesa';
  phoneNumber: string;
}

export interface CardPayment {
  method: 'visa' | 'mastercard';
  cardNumber: string;
  expiry: string;
  cvv: string;
  cardName: string;
}

export interface BankPayment {
  method: 'bank';
  reference?: string;
}

export type PaymentDetails = MpesaPayment | CardPayment | BankPayment;

export interface Order {
  id: string;
  items: CartItem[];
  delivery: DeliveryAddress;
  payment: PaymentDetails;
  subtotal: number;
  vat: number;
  deliveryFee: number;
  total: number;
  status: 'pending' | 'confirmed' | 'processing' | 'shipped' | 'delivered';
  createdAt: Date;
}

// ─── Navigation ──────────────────────────────────────────────
export interface NavLink {
  label: string;
  href: string;
  badge?: string;
}

// ─── Toast ───────────────────────────────────────────────────
export type ToastType = 'success' | 'error' | 'info' | 'warning';

export interface Toast {
  id: string;
  icon: string;
  message: string;
  type: ToastType;
  duration?: number;
}
