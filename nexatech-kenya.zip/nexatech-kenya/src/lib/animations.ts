'use client';

import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

// Register GSAP plugins (safe to call multiple times)
if (typeof window !== 'undefined') {
  gsap.registerPlugin(ScrollTrigger);
}

// ─── Stagger fade-up for a list of elements ──────────────────
export function staggerFadeUp(
  targets: string | Element | Element[],
  options: {
    delay?:   number;
    stagger?: number;
    duration?: number;
    y?:       number;
    trigger?: string | Element;
  } = {},
) {
  const { delay = 0, stagger = 0.1, duration = 0.7, y = 32, trigger } = options;

  return gsap.from(targets, {
    opacity: 0,
    y,
    duration,
    stagger,
    delay,
    ease:     'power3.out',
    scrollTrigger: trigger
      ? {
          trigger,
          start:   'top 80%',
          once:    true,
        }
      : undefined,
  });
}

// ─── Parallax section ────────────────────────────────────────
export function parallaxSection(
  target: string | Element,
  options: { speed?: number; trigger?: string | Element } = {},
) {
  const { speed = 0.5, trigger } = options;

  return gsap.to(target, {
    yPercent: speed * -50,
    ease:     'none',
    scrollTrigger: {
      trigger: (trigger ?? target) as string | Element,
      start:   'top bottom',
      end:     'bottom top',
      scrub:   true,
    },
  });
}

// ─── Reveal on scroll ────────────────────────────────────────
export function revealOnScroll(
  targets: string,
  containerSelector?: string,
) {
  return gsap.utils.toArray<Element>(targets).forEach((el, i) => {
    gsap.from(el, {
      opacity:  0,
      y:        30,
      duration: 0.65,
      delay:    i * 0.06,
      ease:     'power3.out',
      scrollTrigger: {
        trigger: el,
        start:   'top 85%',
        once:    true,
      },
    });
  });
}

// ─── Counter animation ───────────────────────────────────────
export function animateCounter(
  el: Element,
  end: number,
  duration = 2,
  prefix = '',
  suffix = '',
) {
  const obj = { val: 0 };
  return gsap.to(obj, {
    val: end,
    duration,
    ease:    'power2.out',
    onUpdate: () => {
      el.textContent = `${prefix}${Math.floor(obj.val).toLocaleString()}${suffix}`;
    },
    scrollTrigger: {
      trigger: el,
      start:   'top 80%',
      once:    true,
    },
  });
}

// ─── Magnetic button ─────────────────────────────────────────
export function magneticButton(
  btn: HTMLElement,
  strength = 0.35,
) {
  const handleMove = (e: MouseEvent) => {
    const rect = btn.getBoundingClientRect();
    const cx   = rect.left + rect.width / 2;
    const cy   = rect.top  + rect.height / 2;
    gsap.to(btn, {
      x:        (e.clientX - cx) * strength,
      y:        (e.clientY - cy) * strength,
      duration: 0.3,
      ease:     'power2.out',
    });
  };

  const handleLeave = () => {
    gsap.to(btn, {
      x:        0,
      y:        0,
      duration: 0.5,
      ease:     'elastic.out(1, 0.4)',
    });
  };

  btn.addEventListener('mousemove',  handleMove);
  btn.addEventListener('mouseleave', handleLeave);

  return () => {
    btn.removeEventListener('mousemove',  handleMove);
    btn.removeEventListener('mouseleave', handleLeave);
  };
}

// ─── Horizontal scroll marquee ───────────────────────────────
export function infiniteMarquee(
  track: HTMLElement,
  speed = 1,
  direction: 'left' | 'right' = 'left',
) {
  const totalWidth = track.scrollWidth / 2;
  return gsap.to(track, {
    x:        direction === 'left' ? -totalWidth : totalWidth,
    duration: totalWidth / (50 * speed),
    ease:     'none',
    repeat:   -1,
    modifiers: {
      x: gsap.utils.unitize(
        direction === 'left'
          ? (x: number) => (parseFloat(x) % totalWidth)
          : (x: number) => (parseFloat(x) % totalWidth),
      ),
    },
  });
}

// ─── Page transition ─────────────────────────────────────────
export const pageTransition = {
  initial:  { opacity: 0, y: 12 },
  animate:  { opacity: 1, y: 0 },
  exit:     { opacity: 0, y: -8 },
  transition: { duration: 0.4, ease: [0.4, 0, 0.2, 1] as number[] },
};

// ─── Framer Motion variants ───────────────────────────────────
export const fadeUpVariants = {
  hidden:  { opacity: 0, y: 24 },
  visible: (delay = 0) => ({
    opacity: 1,
    y:       0,
    transition: { duration: 0.65, ease: [0.19, 1, 0.22, 1], delay },
  }),
};

export const staggerContainer = (stagger = 0.08, delayChildren = 0.1) => ({
  hidden:  {},
  visible: { transition: { staggerChildren: stagger, delayChildren } },
});

export const scaleIn = {
  hidden:  { opacity: 0, scale: 0.9 },
  visible: { opacity: 1, scale: 1, transition: { duration: 0.4, ease: [0.19, 1, 0.22, 1] } },
};

export const slideInLeft = {
  hidden:  { opacity: 0, x: -24 },
  visible: { opacity: 1, x: 0,  transition: { duration: 0.5, ease: [0.19, 1, 0.22, 1] } },
};

export const slideInRight = {
  hidden:  { opacity: 0, x: 24 },
  visible: { opacity: 1, x: 0,  transition: { duration: 0.5, ease: [0.19, 1, 0.22, 1] } },
};
