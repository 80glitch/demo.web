import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

// ─── Tailwind class merge ─────────────────────────────────────
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// ─── Currency formatting ──────────────────────────────────────
export function formatKES(amount: number, compact = false): string {
  if (compact && amount >= 1_000_000) {
    return `KES ${(amount / 1_000_000).toFixed(1)}M`;
  }
  if (compact && amount >= 1_000) {
    return `KES ${(amount / 1_000).toFixed(0)}K`;
  }
  return `KES ${amount.toLocaleString('en-KE')}`;
}

export function formatNumber(n: number): string {
  return n.toLocaleString('en-KE');
}

// ─── Discount percentage ──────────────────────────────────────
export function calcDiscount(price: number, oldPrice?: number): number {
  if (!oldPrice || oldPrice <= price) return 0;
  return Math.round(((oldPrice - price) / oldPrice) * 100);
}

// ─── Star rating helpers ──────────────────────────────────────
export function starArray(rating: number): Array<'full' | 'half' | 'empty'> {
  return Array.from({ length: 5 }, (_, i) => {
    if (i < Math.floor(rating)) return 'full';
    if (i < rating) return 'half';
    return 'empty';
  });
}

// ─── Slug helpers ─────────────────────────────────────────────
export function slugify(str: string): string {
  return str
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '');
}

// ─── Truncate ─────────────────────────────────────────────────
export function truncate(str: string, n: number): string {
  return str.length > n ? str.slice(0, n - 1) + '…' : str;
}

// ─── Random id ────────────────────────────────────────────────
export function uid(): string {
  return Math.random().toString(36).slice(2, 9);
}

// ─── Clamp ────────────────────────────────────────────────────
export function clamp(val: number, min: number, max: number): number {
  return Math.min(Math.max(val, min), max);
}

// ─── Map range ────────────────────────────────────────────────
export function mapRange(
  value: number,
  inMin: number, inMax: number,
  outMin: number, outMax: number,
): number {
  return ((value - inMin) / (inMax - inMin)) * (outMax - outMin) + outMin;
}

// ─── Debounce ─────────────────────────────────────────────────
export function debounce<T extends (...args: unknown[]) => void>(
  fn: T,
  delay: number,
): (...args: Parameters<T>) => void {
  let timer: ReturnType<typeof setTimeout>;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), delay);
  };
}

// ─── Product badge colour class ──────────────────────────────
export function badgeClass(badge: string | null): string {
  switch (badge) {
    case 'New':     return 'badge-new';
    case 'Hot':     return 'badge-hot';
    case 'Sale':    return 'badge-sale';
    case 'Limited': return 'badge-limited';
    default:        return '';
  }
}

// ─── Stagger delay for animation ─────────────────────────────
export function staggerDelay(index: number, base = 0.05): number {
  return index * base;
}

// ─── Generate particle props ─────────────────────────────────
export function generateParticles(count = 35) {
  return Array.from({ length: count }, (_, i) => ({
    id: i,
    left: `${Math.random() * 100}%`,
    size: Math.random() * 4 + 2,
    duration: Math.random() * 15 + 10,
    delay: Math.random() * -15,
    opacity: Math.random() * 0.5 + 0.2,
    cyan: Math.random() > 0.5,
  }));
}

// ─── Local storage safe get/set ──────────────────────────────
export const storage = {
  get<T>(key: string, fallback: T): T {
    if (typeof window === 'undefined') return fallback;
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : fallback;
    } catch {
      return fallback;
    }
  },
  set(key: string, value: unknown): void {
    if (typeof window === 'undefined') return;
    try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* noop */ }
  },
  remove(key: string): void {
    if (typeof window === 'undefined') return;
    try { localStorage.removeItem(key); } catch { /* noop */ }
  },
};
