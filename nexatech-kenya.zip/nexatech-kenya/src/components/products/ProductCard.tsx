'use client';

import { useState } from 'react';
import { m, AnimatePresence } from 'framer-motion';
import { Heart, ShoppingCart, Eye, GitCompare, Star } from 'lucide-react';
import { useStore } from '@/store';
import { cn, formatKES, calcDiscount, badgeClass, starArray } from '@/lib/utils';
import type { Product } from '@/types';
import toast from 'react-hot-toast';

interface Props {
  product: Product;
  index?: number;
}

export function ProductCard({ product, index = 0 }: Props) {
  const [cartAnim, setCartAnim] = useState(false);
  const [heartAnim, setHeartAnim] = useState(false);

  const { addToCart, toggleWishlist, isWishlisted, openModal, addToCompare } = useStore(s => ({
    addToCart:     s.addToCart,
    toggleWishlist: s.toggleWishlist,
    isWishlisted:  s.isWishlisted(product.id),
    openModal:     s.openModal,
    addToCompare:  s.addToCompare,
  }));

  const discount  = calcDiscount(product.price, product.oldPrice);
  const stars     = starArray(product.rating);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product);
    setCartAnim(true);
    setTimeout(() => setCartAnim(false), 500);
    toast.success(`${product.name} added to cart!`);
  };

  const handleWishlist = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleWishlist(product.id);
    setHeartAnim(true);
    setTimeout(() => setHeartAnim(false), 400);
    toast(isWishlisted ? 'Removed from wishlist' : 'Added to wishlist!', {
      icon: isWishlisted ? '💔' : '❤️',
    });
  };

  const handleCompare = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCompare(product.name.split(' ').slice(0,3).join(' '));
    toast('Added to comparison', { icon: '📊' });
  };

  return (
    <m.article
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.45, delay: index * 0.06, ease: [0.19,1,0.22,1] }}
      whileHover={{ y: -7, transition: { duration: 0.3 } }}
      onClick={() => openModal(product.id)}
      className="group relative bg-white/[0.04] border border-white/[0.08] rounded-[22px] overflow-hidden cursor-pointer transition-[border-color,box-shadow] duration-300 hover:border-[rgba(30,144,255,0.35)] hover:shadow-[0_8px_40px_rgba(30,144,255,0.2)]"
    >
      {/* Image area */}
      <div className="relative h-44 bg-gradient-to-br from-[#111827] to-[#1a2332] flex items-center justify-center overflow-hidden">
        {/* Radial glow behind icon */}
        <div
          className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
          style={{ background: 'radial-gradient(circle at 50% 70%, rgba(30,144,255,0.1), transparent 65%)' }}
          aria-hidden="true"
        />

        {/* Badge */}
        {product.badge && (
          <span className={cn('absolute top-3 left-3 text-[11px] font-bold px-2 py-0.5 rounded-[6px] z-10', badgeClass(product.badge))}>
            {product.badge}
          </span>
        )}

        {/* Discount */}
        {discount > 0 && (
          <span className="absolute top-3 right-12 text-[11px] font-bold text-[#ff3366] bg-[rgba(255,51,102,0.1)] border border-[rgba(255,51,102,0.2)] px-2 py-0.5 rounded-[6px]">
            -{discount}%
          </span>
        )}

        {/* Wishlist button */}
        <button
          onClick={handleWishlist}
          aria-label={isWishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
          className={cn(
            'absolute top-3 right-3 w-8 h-8 rounded-[8px] flex items-center justify-center z-10 transition-all duration-200',
            isWishlisted
              ? 'bg-[rgba(255,51,102,0.15)] border border-[rgba(255,51,102,0.4)] text-[#ff3366]'
              : 'bg-white/[0.08] border border-white/[0.1] text-nt-text3 hover:bg-[rgba(255,51,102,0.12)] hover:border-[rgba(255,51,102,0.3)] hover:text-[#ff3366]',
            heartAnim && 'heart-pop',
          )}
        >
          <Heart size={14} fill={isWishlisted ? '#ff3366' : 'none'} />
        </button>

        {/* Product icon */}
        <span className="text-[3.5rem] transition-transform duration-300 group-hover:scale-110 select-none" role="img" aria-label={product.name}>
          {product.icon}
        </span>
      </div>

      {/* Body */}
      <div className="p-5">
        <p className="text-[11px] font-bold uppercase tracking-[0.08em] text-[#00d4ff] mb-0.5">{product.brand}</p>
        <h3 className="text-[0.93rem] font-semibold text-nt-text1 mb-1 leading-snug line-clamp-2">{product.name}</h3>

        {/* Stars */}
        <div className="flex items-center gap-1 mb-2" aria-label={`${product.rating} out of 5 stars`}>
          {stars.map((s, i) => (
            <Star key={i} size={12} className={s === 'full' ? 'fill-[#fbbf24] text-[#fbbf24]' : 'text-nt-text3'} />
          ))}
          <span className="text-xs text-nt-text3 ml-1">({product.reviewCount})</span>
        </div>

        <p className="text-xs text-nt-text3 mb-4 leading-relaxed line-clamp-2">{product.shortSpecs}</p>

        {/* Price + cart */}
        <div className="flex items-center justify-between mb-3">
          <div>
            <span className="text-lg font-extrabold text-nt-text1">
              KES <span className="text-[#00d4ff]">{product.price.toLocaleString()}</span>
            </span>
            {product.oldPrice && (
              <span className="text-xs text-nt-text3 line-through ml-2">
                KES {product.oldPrice.toLocaleString()}
              </span>
            )}
          </div>

          <m.button
            onClick={handleAddToCart}
            whileTap={{ scale: 0.9 }}
            aria-label={`Add ${product.name} to cart`}
            className={cn(
              'flex items-center gap-1.5 px-3 py-2 rounded-[9px] text-xs font-bold transition-all duration-200',
              cartAnim
                ? 'bg-[rgba(57,255,20,0.15)] border border-[rgba(57,255,20,0.3)] text-[#39ff14]'
                : 'bg-gradient-to-r from-[#1e90ff] to-[#00d4ff] text-white hover:shadow-[0_4px_16px_rgba(30,144,255,0.35)] hover:-translate-y-0.5',
            )}
          >
            <AnimatePresence mode="wait">
              {cartAnim ? (
                <m.span key="check" initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }}>✓</m.span>
              ) : (
                <m.span key="cart" initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }}>
                  <ShoppingCart size={13} />
                </m.span>
              )}
            </AnimatePresence>
            {cartAnim ? 'Added!' : 'Add'}
          </m.button>
        </div>

        {/* Secondary actions */}
        <div className="flex gap-2">
          <button
            onClick={(e) => { e.stopPropagation(); openModal(product.id); }}
            className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-[9px] text-xs font-medium bg-white/[0.04] border border-white/[0.08] text-nt-text2 hover:border-[rgba(30,144,255,0.3)] hover:text-[#00d4ff] transition-all duration-200"
          >
            <Eye size={12} /> Quick View
          </button>
          <button
            onClick={handleCompare}
            className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-[9px] text-xs font-medium bg-white/[0.04] border border-white/[0.08] text-nt-text2 hover:border-[rgba(30,144,255,0.3)] hover:text-[#00d4ff] transition-all duration-200"
            aria-label="Add to compare"
          >
            <GitCompare size={12} />
          </button>
        </div>
      </div>

      {/* Bottom border glow on hover */}
      <div
        className="absolute bottom-0 left-0 right-0 h-px opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
        style={{ background: 'linear-gradient(90deg, transparent, #1e90ff, transparent)' }}
        aria-hidden="true"
      />
    </m.article>
  );
}
