'use client';

import { useRef } from 'react';
import { m, useInView, AnimatePresence } from 'framer-motion';
import { Plus, X, ShoppingCart, Trash2 } from 'lucide-react';
import { SETUP_ACCESSORIES } from '@/data';
import { useStore } from '@/store';
import { formatKES, cn } from '@/lib/utils';
import toast from 'react-hot-toast';

export function BuildSetupSection() {
  const ref    = useRef<HTMLElement>(null);
  const inView = useInView(ref, { once: true, margin: '-80px' });

  const { setupItems, addToSetup, removeFromSetup, clearSetup, setupTotal, addToCart } = useStore(s => ({
    setupItems:      s.setupItems,
    addToSetup:      s.addToSetup,
    removeFromSetup: s.removeFromSetup,
    clearSetup:      s.clearSetup,
    setupTotal:      s.setupTotal(),
    addToCart:       s.addToCart,
  }));

  const handleAdd = (id: string) => {
    const acc = SETUP_ACCESSORIES.find(a => a.id === id);
    if (!acc) return;
    addToSetup(acc);
    toast.success(`${acc.name} added to setup!`);
  };

  const handleAddAllToCart = () => {
    if (setupItems.length === 0) { toast.error('Add some accessories first!'); return; }
    // Add a representative "setup" product to cart
    const setupProduct = {
      id: 999,
      brand: 'NexaTech',
      name: `Custom Setup (${setupItems.length} items)`,
      slug: 'custom-setup',
      shortSpecs: setupItems.map(i => i.name).join(', '),
      specs: [],
      price: setupTotal,
      icon: '🖥️',
      category: 'accessories' as const,
      badge: null,
      rating: 5,
      reviewCount: 0,
      inStock: true,
      sku: 'CUSTOM-SETUP',
      tags: [],
    };
    addToCart(setupProduct);
    toast.success(`Setup (${setupItems.length} items) added to cart!`);
  };

  return (
    <section ref={ref} id="setup" className="py-20 px-6 bg-[#0d1117]">
      <div className="max-w-[1100px] mx-auto">

        {/* Header */}
        <m.div
          initial={{ opacity: 0, y: 24 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <p className="section-eyebrow mb-3">Build Your Setup</p>
          <h2 className="font-display font-bold text-nt-text1 mb-4"
              style={{ fontSize: 'clamp(1.75rem,3vw,2.5rem)' }}>
            Design Your Dream Workspace
          </h2>
          <p className="text-nt-text2 max-w-md mx-auto">
            Click accessories to add them to your workspace. Total price updates in real time.
          </p>
        </m.div>

        <m.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.15 }}
          className="grid grid-cols-1 lg:grid-cols-[1fr_300px] gap-6 items-start"
        >
          {/* ── Left: Workspace + total ── */}
          <div className="flex flex-col gap-5">

            {/* Workspace dropzone */}
            <div
              className={cn(
                'relative min-h-[300px] rounded-[22px] border-2 transition-all duration-300 p-5',
                setupItems.length > 0
                  ? 'border-[rgba(30,144,255,0.35)] bg-[rgba(30,144,255,0.03)]'
                  : 'border-dashed border-white/[0.12] bg-white/[0.02]',
              )}
            >
              {/* Empty state */}
              <AnimatePresence>
                {setupItems.length === 0 && (
                  <m.div
                    initial={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="absolute inset-0 flex flex-col items-center justify-center gap-3 pointer-events-none select-none"
                  >
                    <span className="text-5xl opacity-20">🖥️</span>
                    <p className="text-nt-text3 text-sm">Click accessories on the right to build your setup</p>
                  </m.div>
                )}
              </AnimatePresence>

              {/* Items */}
              <div className="flex flex-wrap gap-3">
                <AnimatePresence>
                  {setupItems.map(item => (
                    <m.div
                      key={item.uid}
                      layout
                      initial={{ opacity: 0, scale: 0.8, y: 10 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.8, y: -10 }}
                      transition={{ type: 'spring', stiffness: 300, damping: 25 }}
                      className="flex items-center gap-3 bg-white/[0.06] border border-[rgba(30,144,255,0.25)] rounded-[14px] px-4 py-3"
                    >
                      <span className="text-2xl">{item.icon}</span>
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-nt-text1 truncate">{item.name}</p>
                        <p className="text-xs text-[#00d4ff]">{formatKES(item.price)}</p>
                      </div>
                      <button
                        onClick={() => removeFromSetup(item.uid)}
                        className="ml-1 w-6 h-6 rounded-full bg-white/[0.05] flex items-center justify-center text-nt-text3 hover:text-[#ff3366] hover:bg-[rgba(255,51,102,0.1)] transition-all"
                        aria-label={`Remove ${item.name}`}
                      >
                        <X size={12} />
                      </button>
                    </m.div>
                  ))}
                </AnimatePresence>
              </div>
            </div>

            {/* Total + actions */}
            <div className="bg-white/[0.04] border border-[rgba(30,144,255,0.2)] rounded-[18px] p-5">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="text-xs text-nt-text3 font-medium mb-1">Total Setup Cost</p>
                  <m.div
                    key={setupTotal}
                    initial={{ scale: 1.05, color: '#00d4ff' }}
                    animate={{ scale: 1, color: '#f0f4ff' }}
                    transition={{ duration: 0.35 }}
                    className="text-3xl font-extrabold text-nt-text1"
                  >
                    KES <span className="text-[#00d4ff]">{setupTotal.toLocaleString()}</span>
                  </m.div>
                  <p className="text-xs text-nt-text3 mt-1">
                    + VAT: KES {Math.round(setupTotal * 0.16).toLocaleString()} ·
                    Grand total: KES {Math.round(setupTotal * 1.16).toLocaleString()}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-nt-text3 mb-1">{setupItems.length} item{setupItems.length !== 1 ? 's' : ''}</p>
                  {setupItems.length > 0 && (
                    <button
                      onClick={() => { clearSetup(); toast('Setup cleared', { icon: '🗑️' }); }}
                      className="flex items-center gap-1.5 text-xs text-[#ff3366] hover:underline"
                    >
                      <Trash2 size={11} /> Clear all
                    </button>
                  )}
                </div>
              </div>

              <button
                onClick={handleAddAllToCart}
                disabled={setupItems.length === 0}
                className={cn(
                  'w-full flex items-center justify-center gap-2 py-3.5 rounded-[14px] font-bold text-sm transition-all duration-200',
                  setupItems.length > 0
                    ? 'bg-gradient-to-r from-[#1e90ff] to-[#00d4ff] text-white hover:shadow-[0_8px_24px_rgba(30,144,255,0.4)] hover:-translate-y-0.5'
                    : 'bg-white/[0.05] text-nt-text3 cursor-not-allowed',
                )}
              >
                <ShoppingCart size={16} />
                Add Entire Setup to Cart
              </button>
            </div>
          </div>

          {/* ── Right: Accessories list ── */}
          <div>
            <p className="text-xs font-bold uppercase tracking-wider text-nt-text3 mb-4">Available Accessories</p>
            <div className="flex flex-col gap-3">
              {SETUP_ACCESSORIES.map((acc, i) => (
                <m.div
                  key={acc.id}
                  initial={{ opacity: 0, x: 20 }}
                  animate={inView ? { opacity: 1, x: 0 } : {}}
                  transition={{ delay: 0.2 + i * 0.05 }}
                  whileHover={{ x: -3 }}
                  className="flex items-center gap-3 bg-white/[0.04] border border-white/[0.08] rounded-[14px] px-4 py-3 hover:border-[rgba(30,144,255,0.28)] transition-all cursor-default"
                >
                  <span className="text-2xl">{acc.icon}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-nt-text1 truncate">{acc.name}</p>
                    <p className="text-xs text-[#00d4ff]">{formatKES(acc.price)}</p>
                  </div>
                  <button
                    onClick={() => handleAdd(acc.id)}
                    className="w-8 h-8 rounded-[9px] bg-gradient-to-br from-[#1e90ff] to-[#00d4ff] text-white flex items-center justify-center flex-shrink-0 hover:shadow-[0_4px_14px_rgba(30,144,255,0.4)] hover:scale-110 transition-all"
                    aria-label={`Add ${acc.name} to setup`}
                  >
                    <Plus size={16} />
                  </button>
                </m.div>
              ))}
            </div>
          </div>
        </m.div>
      </div>
    </section>
  );
}
