'use client';

import { useRef, useState } from 'react';
import { m, useInView, AnimatePresence } from 'framer-motion';
import { Lock, Truck, RefreshCw, Shield, CheckCircle, ShoppingCart } from 'lucide-react';
import { useStore } from '@/store';
import { formatKES, cn } from '@/lib/utils';
import type { PaymentMethod } from '@/types';
import toast from 'react-hot-toast';

// ─── Trust badges ────────────────────────────────────────────
const TRUST = [
  { icon: <Lock size={13} />,       label: 'SSL Secured'       },
  { icon: <CheckCircle size={13} />, label: 'M-Pesa Safe'       },
  { icon: <RefreshCw size={13} />,   label: 'Easy Returns'      },
  { icon: <Truck size={13} />,       label: '2hr Delivery (CBD)' },
  { icon: <Shield size={13} />,      label: 'Genuine Products'  },
];

// ─── Payment method panels ───────────────────────────────────
function MpesaPanel({ phone, setPhone }: { phone: string; setPhone: (v: string) => void }) {
  return (
    <div>
      <div className="mpesa-bg rounded-[14px] p-4 mb-5">
        <div className="flex items-center gap-2 mb-1.5">
          <span className="text-xl">📱</span>
          <span className="font-bold text-sm mpesa-green">M-Pesa STK Push</span>
        </div>
        <p className="text-sm text-nt-text2 leading-relaxed">
          Enter your Safaricom number. You'll receive a payment prompt on your phone immediately.
          No card needed — just approve the push.
        </p>
      </div>
      <div className="flex flex-col gap-1.5">
        <label className="text-xs font-semibold uppercase tracking-wider text-nt-text2">M-Pesa Number</label>
        <input
          type="tel"
          value={phone}
          onChange={e => setPhone(e.target.value)}
          placeholder="0712 345 678"
          className="nt-input"
          autoComplete="tel"
        />
      </div>
    </div>
  );
}

function CardPanel({ label }: { label: string }) {
  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-col gap-1.5">
        <label className="text-xs font-semibold uppercase tracking-wider text-nt-text2">Card Number</label>
        <input type="text" placeholder="1234 5678 9012 3456" maxLength={19} className="nt-input" autoComplete="cc-number" />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-semibold uppercase tracking-wider text-nt-text2">Expiry</label>
          <input type="text" placeholder="MM/YY" maxLength={5} className="nt-input" autoComplete="cc-exp" />
        </div>
        <div className="flex flex-col gap-1.5">
          <label className="text-xs font-semibold uppercase tracking-wider text-nt-text2">CVV</label>
          <input type="text" placeholder="123" maxLength={4} className="nt-input" autoComplete="cc-csc" />
        </div>
      </div>
      <div className="flex flex-col gap-1.5">
        <label className="text-xs font-semibold uppercase tracking-wider text-nt-text2">Name on {label}</label>
        <input type="text" placeholder="JOHN KAMAU" className="nt-input" autoComplete="cc-name" />
      </div>
    </div>
  );
}

function BankPanel() {
  return (
    <div className="bg-[rgba(30,144,255,0.05)] border border-[rgba(30,144,255,0.2)] rounded-[14px] p-5">
      <div className="flex items-center gap-2 mb-3">
        <span className="text-xl">🏦</span>
        <span className="font-bold text-sm text-[#1e90ff]">Bank Transfer Details</span>
      </div>
      <div className="grid grid-cols-2 gap-x-6 gap-y-2 text-sm">
        {[
          ['Bank',    'KCB Kenya'],
          ['Account', '1234567890'],
          ['Branch',  'Nairobi CBD'],
          ['Name',    'NexaTech Kenya Ltd'],
        ].map(([k, v]) => (
          <div key={k}>
            <p className="text-xs text-nt-text3 mb-0.5">{k}</p>
            <p className="font-semibold text-nt-text1">{v}</p>
          </div>
        ))}
      </div>
      <p className="text-xs text-nt-text3 mt-4 leading-relaxed">
        Use your <span className="text-nt-text2 font-semibold">Order Number</span> as the payment reference.
        Your order will be confirmed within <span className="text-nt-text2 font-semibold">2 business hours</span> of payment receipt.
      </p>
    </div>
  );
}

// ─── Order summary sidebar ───────────────────────────────────
function OrderSummary() {
  const { cartItems, cartTotal, cartVat, cartGrandTotal } = useStore(s => ({
    cartItems:      s.cartItems,
    cartTotal:      s.cartTotal(),
    cartVat:        s.cartVat(),
    cartGrandTotal: s.cartGrandTotal(),
  }));

  return (
    <div className="bg-white/[0.04] border border-white/[0.08] rounded-[22px] p-5 sticky top-24">
      <p className="font-bold text-base text-nt-text1 mb-5">Order Summary</p>

      {cartItems.length === 0 ? (
        <div className="text-center py-10 text-nt-text3">
          <ShoppingCart size={36} className="mx-auto mb-3 opacity-30" />
          <p className="text-sm">Your cart is empty</p>
          <button
            onClick={() => document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' })}
            className="mt-3 text-[#00d4ff] text-sm font-semibold hover:underline"
          >
            Browse products →
          </button>
        </div>
      ) : (
        <>
          <div className="flex flex-col gap-3 mb-5">
            {cartItems.map(item => (
              <div key={item.product.id} className="flex items-center gap-3">
                <span className="text-2xl">{item.product.icon}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold text-nt-text1 leading-snug line-clamp-2">{item.product.name}</p>
                  <p className="text-xs text-nt-text3">Qty: {item.qty}</p>
                </div>
                <p className="text-sm font-bold text-nt-text1 flex-shrink-0">
                  {formatKES(item.product.price * item.qty)}
                </p>
              </div>
            ))}
          </div>

          <div className="border-t border-white/[0.08] pt-4 flex flex-col gap-2.5">
            <div className="flex justify-between text-sm text-nt-text2">
              <span>Subtotal</span><span>{formatKES(cartTotal)}</span>
            </div>
            <div className="flex justify-between text-sm text-nt-text2">
              <span>Delivery (Nairobi CBD)</span>
              <span className="text-[#39ff14] font-semibold">FREE</span>
            </div>
            <div className="flex justify-between text-sm text-nt-text2">
              <span>VAT (16%)</span><span>{formatKES(cartVat)}</span>
            </div>
            <div className="flex justify-between font-extrabold text-base text-nt-text1 border-t border-white/[0.08] pt-3 mt-1">
              <span>Total</span><span className="text-[#00d4ff]">{formatKES(cartGrandTotal)}</span>
            </div>
          </div>
        </>
      )}

      {/* Trust badges */}
      <div className="flex flex-wrap gap-2 mt-5 pt-4 border-t border-white/[0.06]">
        {TRUST.map(t => (
          <div key={t.label} className="flex items-center gap-1.5 text-[11px] text-nt-text3 bg-white/[0.03] border border-white/[0.06] rounded-[7px] px-2.5 py-1.5">
            <span className="text-nt-text3">{t.icon}</span>{t.label}
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Main component ──────────────────────────────────────────
export function CheckoutSection() {
  const ref    = useRef<HTMLElement>(null);
  const inView = useInView(ref, { once: true, margin: '-80px' });

  const [payMethod, setPayMethod] = useState<PaymentMethod>('mpesa');
  const [mpesaPhone, setMpesaPhone] = useState('');
  const [placing, setPlacing] = useState(false);

  const { cartItems, clearCart } = useStore(s => ({
    cartItems: s.cartItems,
    clearCart: s.clearCart,
  }));

  const PAY_TABS: { id: PaymentMethod; label: string; icon: string }[] = [
    { id: 'mpesa',      label: 'M-Pesa',       icon: '📱' },
    { id: 'visa',       label: 'Visa',         icon: '💳' },
    { id: 'mastercard', label: 'Mastercard',   icon: '🔴' },
    { id: 'bank',       label: 'Bank Transfer', icon: '🏦' },
  ];

  const handlePlaceOrder = async () => {
    if (cartItems.length === 0) { toast.error('Add products to your cart first!'); return; }
    setPlacing(true);
    await new Promise(r => setTimeout(r, 1800));
    setPlacing(false);
    clearCart();
    toast.success('Order placed! 🎉 Check your phone for the M-Pesa prompt.', { duration: 5000 });
  };

  return (
    <section ref={ref} id="checkout" className="py-20 px-6 bg-[#0d1117]">
      <div className="max-w-[1000px] mx-auto">

        {/* Header */}
        <m.div
          initial={{ opacity: 0, y: 24 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <p className="section-eyebrow mb-3">Secure Checkout</p>
          <h2 className="font-display font-bold text-nt-text1 mb-4"
              style={{ fontSize: 'clamp(1.75rem,3vw,2.5rem)' }}>
            Complete Your Order
          </h2>
          <p className="text-nt-text2 max-w-md mx-auto">
            Fast, secure checkout. Pay with M-Pesa, card, or bank transfer.
          </p>
        </m.div>

        <m.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.15 }}
          className="grid grid-cols-1 lg:grid-cols-[1fr_340px] gap-7 items-start"
        >
          {/* ── Form ── */}
          <div className="bg-white/[0.04] border border-white/[0.08] rounded-[22px] p-6 sm:p-8">

            {/* Delivery info */}
            <p className="font-bold text-base text-nt-text1 flex items-center gap-2 mb-5">
              <Truck size={18} className="text-[#00d4ff]" /> Delivery Information
            </p>
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold uppercase tracking-wider text-nt-text2">First Name</label>
                <input className="nt-input" type="text" placeholder="John" autoComplete="given-name" />
              </div>
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold uppercase tracking-wider text-nt-text2">Last Name</label>
                <input className="nt-input" type="text" placeholder="Kamau" autoComplete="family-name" />
              </div>
            </div>
            <div className="flex flex-col gap-1.5 mb-4">
              <label className="text-xs font-semibold uppercase tracking-wider text-nt-text2">Phone Number</label>
              <input className="nt-input" type="tel" placeholder="+254 712 345 678" autoComplete="tel" />
            </div>
            <div className="flex flex-col gap-1.5 mb-4">
              <label className="text-xs font-semibold uppercase tracking-wider text-nt-text2">Email Address</label>
              <input className="nt-input" type="email" placeholder="john@example.com" autoComplete="email" />
            </div>
            <div className="flex flex-col gap-1.5 mb-4">
              <label className="text-xs font-semibold uppercase tracking-wider text-nt-text2">Delivery Address</label>
              <input className="nt-input" type="text" placeholder="Street, Estate, Building, Floor" autoComplete="street-address" />
            </div>
            <div className="grid grid-cols-2 gap-4 mb-8">
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold uppercase tracking-wider text-nt-text2">City</label>
                <input className="nt-input" type="text" placeholder="Nairobi" autoComplete="address-level2" />
              </div>
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-semibold uppercase tracking-wider text-nt-text2">Area / Estate</label>
                <input className="nt-input" type="text" placeholder="Westlands" />
              </div>
            </div>

            {/* Payment method */}
            <p className="font-bold text-base text-nt-text1 flex items-center gap-2 mb-5">
              <Lock size={18} className="text-[#00d4ff]" /> Payment Method
            </p>

            {/* Payment tabs */}
            <div className="flex flex-wrap gap-2 mb-6">
              {PAY_TABS.map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setPayMethod(tab.id)}
                  className={cn(
                    'flex items-center gap-2 px-4 py-2.5 rounded-[12px] text-sm font-semibold border transition-all duration-200',
                    payMethod === tab.id
                      ? 'bg-[rgba(30,144,255,0.14)] border-[rgba(30,144,255,0.45)] text-[#00d4ff]'
                      : 'bg-white/[0.04] border-white/[0.08] text-nt-text2 hover:border-[rgba(30,144,255,0.25)] hover:text-nt-text1',
                  )}
                >
                  <span>{tab.icon}</span>{tab.label}
                </button>
              ))}
            </div>

            {/* Payment panel */}
            <AnimatePresence mode="wait">
              <m.div
                key={payMethod}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.25 }}
                className="mb-8"
              >
                {payMethod === 'mpesa'      && <MpesaPanel phone={mpesaPhone} setPhone={setMpesaPhone} />}
                {payMethod === 'visa'       && <CardPanel label="Visa" />}
                {payMethod === 'mastercard' && <CardPanel label="Mastercard" />}
                {payMethod === 'bank'       && <BankPanel />}
              </m.div>
            </AnimatePresence>

            {/* Submit */}
            <button
              onClick={handlePlaceOrder}
              disabled={placing}
              className={cn(
                'w-full flex items-center justify-center gap-2.5 py-4 rounded-[16px] font-bold text-base transition-all duration-200',
                placing
                  ? 'bg-[rgba(30,144,255,0.3)] text-white cursor-wait'
                  : 'bg-gradient-to-r from-[#1e90ff] to-[#00d4ff] text-white hover:shadow-[0_10px_32px_rgba(30,144,255,0.45)] hover:-translate-y-0.5',
              )}
            >
              {placing ? (
                <>
                  <m.span animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 0.8, ease: 'linear' }}>
                    ⏳
                  </m.span>
                  Processing…
                </>
              ) : (
                <>
                  <Lock size={17} /> Place Order Securely
                </>
              )}
            </button>

            <p className="text-center text-xs text-nt-text3 mt-4">
              By placing your order you agree to our{' '}
              <span className="text-[#00d4ff] cursor-pointer hover:underline">Terms of Service</span>
              {' '}and{' '}
              <span className="text-[#00d4ff] cursor-pointer hover:underline">Privacy Policy</span>.
            </p>
          </div>

          {/* ── Summary ── */}
          <OrderSummary />
        </m.div>
      </div>
    </section>
  );
}
