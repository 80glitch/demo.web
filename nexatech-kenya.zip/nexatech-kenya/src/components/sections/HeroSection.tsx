'use client';

import { useEffect, useRef, Suspense } from 'react';
import { m } from 'framer-motion';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float, MeshDistortMaterial, Sphere } from '@react-three/drei';
import * as THREE from 'three';
import { gsap } from 'gsap';
import { ChevronDown, Zap, ArrowRight } from 'lucide-react';
import { HERO_STATS } from '@/data';
import { formatNumber } from '@/lib/utils';

// ─── Three.js floating orb ──────────────────────────────────
function FloatingOrb() {
  const meshRef = useRef<THREE.Mesh>(null!);

  useFrame((state) => {
    if (!meshRef.current) return;
    meshRef.current.rotation.x = state.clock.getElapsedTime() * 0.15;
    meshRef.current.rotation.y = state.clock.getElapsedTime() * 0.2;
  });

  return (
    <Float speed={2} rotationIntensity={0.5} floatIntensity={1.5}>
      <Sphere ref={meshRef} args={[1.8, 64, 64]}>
        <MeshDistortMaterial
          color="#1e90ff"
          attach="material"
          distort={0.35}
          speed={2.5}
          roughness={0.15}
          metalness={0.9}
          opacity={0.18}
          transparent
          wireframe={false}
        />
      </Sphere>
      <Sphere args={[1.82, 64, 64]}>
        <meshBasicMaterial
          color="#00d4ff"
          wireframe
          opacity={0.05}
          transparent
        />
      </Sphere>
    </Float>
  );
}

// ─── Particle component ─────────────────────────────────────
function Particles() {
  const particles = Array.from({ length: 40 }, (_, i) => ({
    id: i,
    left:     `${Math.random() * 100}%`,
    size:      Math.random() * 4 + 1.5,
    duration:  Math.random() * 18 + 10,
    delay:    -(Math.random() * 18),
    cyan:      Math.random() > 0.5,
    opacity:   Math.random() * 0.5 + 0.15,
  }));

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none" aria-hidden="true">
      {particles.map(p => (
        <div
          key={p.id}
          className="absolute rounded-full"
          style={{
            left: p.left,
            width:  p.size,
            height: p.size,
            background: p.cyan
              ? `rgba(0,212,255,${p.opacity})`
              : `rgba(30,144,255,${p.opacity})`,
            animation: `particle-float ${p.duration}s linear ${p.delay}s infinite`,
          }}
        />
      ))}
    </div>
  );
}

// ─── Laptop SVG ─────────────────────────────────────────────
function LaptopIllustration() {
  return (
    <svg
      viewBox="0 0 440 300"
      xmlns="http://www.w3.org/2000/svg"
      className="w-full h-full drop-shadow-[0_0_40px_rgba(30,144,255,0.25)]"
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="lgScreen" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#0d1117" />
          <stop offset="100%" stopColor="#1a2332" />
        </linearGradient>
        <linearGradient id="lgBody" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#1a2332" />
          <stop offset="100%" stopColor="#0a0e18" />
        </linearGradient>
        <linearGradient id="lgGlow" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%"   stopColor="#1e90ff" stopOpacity="0" />
          <stop offset="50%"  stopColor="#00d4ff" stopOpacity="0.7" />
          <stop offset="100%" stopColor="#1e90ff" stopOpacity="0" />
        </linearGradient>
        <radialGradient id="lgScreenGlow" cx="50%" cy="50%" r="50%">
          <stop offset="0%"   stopColor="#1e90ff" stopOpacity="0.08" />
          <stop offset="100%" stopColor="#1e90ff" stopOpacity="0" />
        </radialGradient>
        <filter id="glow">
          <feGaussianBlur stdDeviation="2" result="blur" />
          <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
        </filter>
      </defs>

      {/* Lid outer */}
      <rect x="40" y="15" width="360" height="210" rx="14" fill="url(#lgBody)" stroke="#1e4a6e" strokeWidth="1.5" />
      {/* Screen bezel */}
      <rect x="52" y="27" width="336" height="187" rx="8" fill="url(#lgScreen)" />
      {/* Screen glow overlay */}
      <rect x="52" y="27" width="336" height="187" rx="8" fill="url(#lgScreenGlow)" />
      {/* Screen content — fake UI */}
      <rect x="68" y="42" width="200" height="9" rx="4.5" fill="#1e90ff" opacity="0.75" filter="url(#glow)" />
      <rect x="68" y="58" width="120" height="6" rx="3" fill="#64748b" opacity="0.5" />
      {/* Mock card 1 */}
      <rect x="68" y="78" width="295" height="72" rx="8" fill="#111827" />
      <rect x="80" y="91" width="90" height="7" rx="3.5" fill="#00d4ff" opacity="0.7" />
      <rect x="80" y="106" width="180" height="5" rx="2.5" fill="#374151" opacity="0.6" />
      <rect x="80" y="118" width="140" height="5" rx="2.5" fill="#374151" opacity="0.4" />
      <rect x="80" y="130" width="60" height="14" rx="5" fill="#1e90ff" opacity="0.7" />
      {/* Mock card 2 */}
      <rect x="68" y="162" width="142" height="38" rx="7" fill="#111827" />
      <rect x="78" y="172" width="55" height="6" rx="3" fill="#7c3aed" opacity="0.8" />
      <rect x="78" y="184" width="100" height="5" rx="2.5" fill="#374151" opacity="0.5" />
      {/* Mock card 3 */}
      <rect x="221" y="162" width="142" height="38" rx="7" fill="#111827" />
      <rect x="231" y="172" width="55" height="6" rx="3" fill="#1e90ff" opacity="0.7" />
      <rect x="231" y="184" width="100" height="5" rx="2.5" fill="#374151" opacity="0.5" />
      {/* Screen edge glow */}
      <line x1="40" y1="228" x2="400" y2="228" stroke="url(#lgGlow)" strokeWidth="0.8" />
      {/* Webcam dot */}
      <circle cx="220" cy="22" r="3" fill="#111827" stroke="#1e4a6e" strokeWidth="0.5" />

      {/* Base / keyboard */}
      <path d="M18 233 L30 228 L410 228 L422 233 L422 270 Q422 278 412 278 L28 278 Q18 278 18 270 Z" fill="url(#lgBody)" stroke="#1e4a6e" strokeWidth="1" />
      {/* Keyboard rows */}
      <rect x="55" y="237" width="330" height="5.5" rx="2.75" fill="#0d1117" opacity="0.55" />
      <rect x="60" y="248" width="320" height="5.5" rx="2.75" fill="#0d1117" opacity="0.55" />
      <rect x="68" y="259" width="305" height="5.5" rx="2.75" fill="#0d1117" opacity="0.55" />
      {/* Touchpad */}
      <rect x="171" y="268" width="98" height="7" rx="3.5" fill="#0d1117" opacity="0.4" stroke="#1e4a6e" strokeWidth="0.5" />
      {/* NexaTech logo on lid */}
      <text x="382" y="43" fontFamily="Inter,sans-serif" fontSize="10" fill="#1e90ff" textAnchor="end" opacity="0.7">NexaTech</text>
    </svg>
  );
}

// ─── Hero Section ────────────────────────────────────────────
const fadeUp = {
  hidden:  { opacity: 0, y: 32 },
  visible: (delay = 0) => ({ opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.19,1,0.22,1], delay } }),
};

export function HeroSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef   = useRef<HTMLHeadingElement>(null);

  // GSAP entrance for the big title
  useEffect(() => {
    if (!titleRef.current) return;
    gsap.from(titleRef.current.querySelectorAll('.gsap-line'), {
      y: 60,
      opacity: 0,
      duration: 0.9,
      stagger: 0.12,
      ease: 'power3.out',
      delay: 0.3,
    });
  }, []);

  const scrollToProducts = () => {
    document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' });
  };
  const scrollToFinder = () => {
    document.getElementById('finder')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section
      ref={sectionRef}
      id="hero"
      className="relative min-h-screen flex items-center overflow-hidden pt-20"
      aria-label="NexaTech Kenya hero"
    >
      {/* Radial bg gradients */}
      <div
        className="absolute inset-0 pointer-events-none"
        aria-hidden="true"
        style={{
          background: 'radial-gradient(ellipse at 60% 50%, rgba(30,144,255,0.11) 0%, transparent 60%), radial-gradient(ellipse at 15% 80%, rgba(124,58,237,0.09) 0%, transparent 50%), #080a0f',
        }}
      />

      <Particles />

      {/* Three.js canvas (desktop only) */}
      <div className="absolute right-0 top-0 bottom-0 w-1/2 pointer-events-none hidden xl:block opacity-70" aria-hidden="true">
        <Canvas camera={{ position: [0, 0, 5], fov: 45 }} dpr={[1, 1.5]}>
          <ambientLight intensity={0.3} />
          <pointLight position={[5, 5, 5]} color="#1e90ff" intensity={3} />
          <pointLight position={[-5, -5, 2]} color="#7c3aed" intensity={1.5} />
          <Suspense fallback={null}>
            <FloatingOrb />
          </Suspense>
        </Canvas>
      </div>

      {/* Decorative rings */}
      <div className="absolute right-16 top-1/2 -translate-y-1/2 hidden lg:block pointer-events-none" aria-hidden="true">
        <div className="w-[520px] h-[520px] rounded-full border border-[rgba(30,144,255,0.12)] animate-spin-slow" />
        <div className="absolute inset-[30px] rounded-full border border-dashed border-[rgba(0,212,255,0.08)] animate-[spin-slower_25s_linear_infinite]" />
      </div>

      {/* Laptop illustration — desktop */}
      <m.div
        initial={{ opacity: 0, x: 60, y: 0 }}
        animate={{ opacity: 1, x: 0, y: 0 }}
        transition={{ duration: 1, delay: 0.4, ease: [0.19, 1, 0.22, 1] }}
        className="absolute right-6 top-1/2 -translate-y-1/2 w-[42vw] max-w-[520px] hidden lg:block pointer-events-none animate-float"
        aria-hidden="true"
      >
        <LaptopIllustration />
      </m.div>

      {/* Content */}
      <div className="relative z-10 w-full max-w-[1200px] mx-auto px-6 py-20 grid grid-cols-1 lg:grid-cols-[1fr_auto] gap-12 items-center">
        <div className="max-w-[620px]">

          {/* Badge */}
          <m.div
            variants={fadeUp}
            initial="hidden"
            animate="visible"
            custom={0.1}
            className="inline-flex items-center gap-2 bg-[rgba(30,144,255,0.1)] border border-[rgba(30,144,255,0.28)] rounded-full px-4 py-1.5 mb-6"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-[#00d4ff] animate-pulse" />
            <span className="text-xs font-bold text-[#00d4ff] tracking-wide">
              Kenya's #1 Premium Tech Marketplace
            </span>
            <Zap size={12} className="text-[#00d4ff]" />
          </m.div>

          {/* Title — GSAP handles the lines */}
          <h1 ref={titleRef} className="font-display font-extrabold leading-[1.08] mb-6">
            <span
              className="gsap-line block text-nt-text1 opacity-0"
              style={{ fontSize: 'clamp(2.6rem, 5.5vw, 4.25rem)' }}
            >
              Power Your World
            </span>
            <span
              className="gsap-line block opacity-0"
              style={{
                fontSize: 'clamp(2.6rem, 5.5vw, 4.25rem)',
                background: 'linear-gradient(135deg,#1e90ff,#00d4ff)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}
            >
              With NexaTech
            </span>
          </h1>

          {/* Subtitle */}
          <m.p
            variants={fadeUp} initial="hidden" animate="visible" custom={0.3}
            className="text-lg text-nt-text2 leading-relaxed mb-10 max-w-[520px]"
          >
            Laptops, gaming rigs, monitors and professional electronics — curated for
            Kenyan professionals, students and creators. M-Pesa accepted. 2-hour delivery in Nairobi.
          </m.p>

          {/* CTA buttons */}
          <m.div
            variants={fadeUp} initial="hidden" animate="visible" custom={0.4}
            className="flex flex-wrap gap-4 mb-12"
          >
            <button
              onClick={scrollToProducts}
              className="flex items-center gap-2 bg-gradient-to-r from-[#1e90ff] to-[#00d4ff] text-white px-7 py-3.5 rounded-[14px] font-bold text-base hover:shadow-[0_8px_30px_rgba(30,144,255,0.45)] hover:-translate-y-0.5 transition-all duration-200"
            >
              Shop Now <ArrowRight size={16} />
            </button>
            <button
              onClick={scrollToFinder}
              className="flex items-center gap-2 bg-white/[0.04] backdrop-blur-md border border-[rgba(30,144,255,0.35)] text-[#00d4ff] px-7 py-3.5 rounded-[14px] font-semibold text-base hover:bg-[rgba(30,144,255,0.1)] hover:-translate-y-0.5 transition-all duration-200"
            >
              <Zap size={16} /> AI Laptop Finder
            </button>
          </m.div>

          {/* Stats */}
          <m.div
            variants={fadeUp} initial="hidden" animate="visible" custom={0.55}
            className="flex flex-wrap gap-8"
          >
            {HERO_STATS.map((stat, i) => (
              <div key={i} className="border-l-2 border-[#1e90ff] pl-4">
                <div className="text-2xl font-extrabold text-nt-text1 leading-none">{stat.value}</div>
                <div className="text-xs text-nt-text3 mt-1">{stat.label}</div>
              </div>
            ))}
          </m.div>
        </div>
      </div>

      {/* Scroll cue */}
      <m.button
        onClick={scrollToProducts}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-nt-text3 hover:text-[#00d4ff] transition-colors flex flex-col items-center gap-1"
        aria-label="Scroll to products"
      >
        <span className="text-xs tracking-widest uppercase">Scroll</span>
        <ChevronDown size={20} className="animate-bounce" />
      </m.button>
    </section>
  );
}
