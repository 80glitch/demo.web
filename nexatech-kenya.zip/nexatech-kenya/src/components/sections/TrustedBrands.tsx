'use client';

import { m } from 'framer-motion';

const BRANDS = ['Apple', 'Dell', 'HP', 'Lenovo', 'ASUS', 'Samsung', 'LG', 'Logitech', 'MSI', 'Razer', 'Ubiquiti', 'Epson', 'Intel', 'NVIDIA'];

export function TrustedBrands() {
  return (
    <div className="bg-[#0d1117] border-y border-white/[0.06] py-5 overflow-hidden">
      <div className="max-w-[1200px] mx-auto px-6">
        <div className="flex items-center gap-8 overflow-x-auto no-scrollbar">
          <span className="text-[11px] font-bold uppercase tracking-widest text-nt-text3 whitespace-nowrap flex-shrink-0">
            Trusted Brands
          </span>
          <div className="flex items-center gap-10 flex-shrink-0">
            {BRANDS.map((brand, i) => (
              <m.span
                key={brand}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.04 }}
                className="text-sm font-bold text-nt-text3 opacity-40 hover:opacity-70 transition-opacity cursor-default whitespace-nowrap select-none"
              >
                {brand}
              </m.span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
