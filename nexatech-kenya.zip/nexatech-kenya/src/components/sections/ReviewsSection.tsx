'use client';

import { useRef, useState } from 'react';
import { m, useInView } from 'framer-motion';
import { Star, Play, CheckCircle, ThumbsUp } from 'lucide-react';
import { REVIEWS } from '@/data';
import { cn } from '@/lib/utils';

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex gap-0.5" aria-label={`${rating} out of 5 stars`}>
      {Array.from({ length: 5 }, (_, i) => (
        <Star
          key={i}
          size={14}
          className={i < rating ? 'fill-[#fbbf24] text-[#fbbf24]' : 'text-nt-text3'}
        />
      ))}
    </div>
  );
}

function ReviewCard({ review, index }: { review: typeof REVIEWS[0]; index: number }) {
  const [helpful, setHelpful] = useState(false);
  const [helpCount, setHelpCount] = useState(Math.floor(Math.random() * 40 + 5));

  return (
    <m.article
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.5, delay: index * 0.07, ease: [0.19,1,0.22,1] }}
      whileHover={{ y: -4 }}
      className="bg-white/[0.04] border border-white/[0.08] rounded-[22px] p-5 hover:border-[rgba(30,144,255,0.28)] hover:shadow-[0_6px_30px_rgba(30,144,255,0.1)] transition-all duration-300 flex flex-col"
    >
      {/* Optional video thumbnail */}
      {review.hasVideo && (
        <div className="relative rounded-[14px] overflow-hidden mb-4 h-[130px] bg-gradient-to-br from-[#111827] to-[#1a2332] flex items-center justify-center cursor-pointer group">
          <div className="absolute inset-0 bg-gradient-to-br from-[rgba(30,144,255,0.05)] to-[rgba(124,58,237,0.05)]" />
          <m.div
            whileHover={{ scale: 1.12 }}
            className="w-12 h-12 rounded-full bg-gradient-to-br from-[#1e90ff] to-[#00d4ff] flex items-center justify-center shadow-[0_0_24px_rgba(30,144,255,0.5)] z-10"
          >
            <Play size={18} className="text-white ml-0.5" fill="white" />
          </m.div>
          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/60 to-transparent p-3">
            <p className="text-xs text-white/80 font-medium">📹 Watch Review</p>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="flex items-center gap-3 mb-4">
        <div className="w-11 h-11 rounded-[12px] flex-shrink-0 bg-gradient-to-br from-[#1e90ff] to-[#7c3aed] flex items-center justify-center text-white font-bold text-sm">
          {review.initials}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold text-nt-text1 leading-tight">{review.author}</p>
          <p className="text-xs text-nt-text3 truncate">📍 {review.location}</p>
        </div>
        {review.verified && (
          <div className="flex items-center gap-1 text-[10px] font-bold text-[#00d4ff] bg-[rgba(0,212,255,0.08)] border border-[rgba(0,212,255,0.2)] px-2 py-0.5 rounded-full flex-shrink-0">
            <CheckCircle size={9} /> Verified
          </div>
        )}
      </div>

      {/* Stars */}
      <StarRating rating={review.rating} />

      {/* Body */}
      <p className="text-sm text-nt-text2 leading-relaxed my-3 flex-1">
        "{review.body}"
      </p>

      {/* Footer */}
      <div className="flex items-center justify-between pt-3 border-t border-white/[0.06]">
        <div className="flex items-center gap-1.5 text-xs text-nt-text3">
          <span className="text-base">🛍️</span>
          <span className="truncate max-w-[140px]">{review.productName}</span>
        </div>
        <button
          onClick={() => {
            if (!helpful) { setHelpful(true); setHelpCount(c => c + 1); }
          }}
          className={cn(
            'flex items-center gap-1.5 text-xs font-medium px-2.5 py-1.5 rounded-[8px] transition-all',
            helpful
              ? 'text-[#00d4ff] bg-[rgba(0,212,255,0.1)] border border-[rgba(0,212,255,0.2)]'
              : 'text-nt-text3 hover:text-nt-text1 hover:bg-white/[0.05]',
          )}
          aria-label="Mark as helpful"
        >
          <ThumbsUp size={12} className={helpful ? 'fill-[#00d4ff]' : ''} />
          {helpCount}
        </button>
      </div>
    </m.article>
  );
}

// ─── Rating summary bar ──────────────────────────────────────
function RatingSummary() {
  const bars = [
    { stars: 5, pct: 78 },
    { stars: 4, pct: 14 },
    { stars: 3, pct: 5  },
    { stars: 2, pct: 2  },
    { stars: 1, pct: 1  },
  ];

  return (
    <m.div
      initial={{ opacity: 0, x: -20 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6 }}
      className="bg-white/[0.04] border border-white/[0.08] rounded-[22px] p-6 flex flex-col sm:flex-row items-center gap-8"
    >
      {/* Big score */}
      <div className="text-center flex-shrink-0">
        <div className="text-6xl font-extrabold text-nt-text1 leading-none">4.8</div>
        <div className="flex justify-center gap-0.5 my-2">
          {[1,2,3,4,5].map(i => <Star key={i} size={16} className="fill-[#fbbf24] text-[#fbbf24]" />)}
        </div>
        <p className="text-xs text-nt-text3">50,000+ reviews</p>
      </div>

      {/* Bars */}
      <div className="flex-1 w-full flex flex-col gap-2">
        {bars.map(b => (
          <div key={b.stars} className="flex items-center gap-3">
            <span className="text-xs text-nt-text3 w-8 text-right">{b.stars}★</span>
            <div className="flex-1 h-2 bg-white/[0.06] rounded-full overflow-hidden">
              <m.div
                initial={{ width: 0 }}
                whileInView={{ width: `${b.pct}%` }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, delay: 0.1, ease: 'easeOut' }}
                className="h-full bg-gradient-to-r from-[#1e90ff] to-[#00d4ff] rounded-full"
              />
            </div>
            <span className="text-xs text-nt-text3 w-8">{b.pct}%</span>
          </div>
        ))}
      </div>

      {/* Highlights */}
      <div className="flex-shrink-0 flex flex-col gap-2 sm:min-w-[160px]">
        {['Fast delivery', 'Genuine products', 'Great support', 'Easy returns'].map(tag => (
          <div key={tag} className="flex items-center gap-2 text-xs text-nt-text2">
            <CheckCircle size={13} className="text-[#39ff14] flex-shrink-0" />
            {tag}
          </div>
        ))}
      </div>
    </m.div>
  );
}

// ─── Main component ──────────────────────────────────────────
export function ReviewsSection() {
  const ref    = useRef<HTMLElement>(null);
  const inView = useInView(ref, { once: true, margin: '-80px' });

  return (
    <section ref={ref} id="reviews" className="py-20 px-6 bg-[#080a0f]">
      <div className="max-w-[1100px] mx-auto">

        {/* Header */}
        <m.div
          initial={{ opacity: 0, y: 24 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-10"
        >
          <p className="section-eyebrow mb-3">Customer Stories</p>
          <h2 className="font-display font-bold text-nt-text1 mb-4"
              style={{ fontSize: 'clamp(1.75rem,3vw,2.5rem)' }}>
            Kenyans Love NexaTech
          </h2>
          <p className="text-nt-text2 max-w-md mx-auto">
            Real reviews from verified customers across Kenya.
          </p>
        </m.div>

        {/* Rating summary */}
        <div className="mb-10">
          <RatingSummary />
        </div>

        {/* Reviews grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {REVIEWS.map((review, i) => (
            <ReviewCard key={review.id} review={review} index={i} />
          ))}
        </div>

        {/* Load more */}
        <m.div
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : {}}
          transition={{ delay: 0.7 }}
          className="text-center mt-10"
        >
          <button className="px-8 py-3.5 rounded-[14px] bg-white/[0.04] border border-white/[0.1] text-nt-text2 font-semibold text-sm hover:bg-white/[0.07] hover:text-nt-text1 hover:border-[rgba(30,144,255,0.3)] transition-all duration-200">
            Load More Reviews
          </button>
        </m.div>
      </div>
    </section>
  );
}
