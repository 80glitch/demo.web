'use client';

import { useRef } from 'react';
import { m, useInView, AnimatePresence } from 'framer-motion';
import { Zap, ArrowRight, ArrowLeft, ShoppingCart, Star } from 'lucide-react';
import { PRODUCTS, FINDER_RECOMMENDATIONS } from '@/data';
import { useStore } from '@/store';
import type { UseCase } from '@/types';
import toast from 'react-hot-toast';
import { cn } from '@/lib/utils';

const USE_CASES: { label: UseCase; icon: string; desc: string }[] = [
  { label: 'Programming',    icon: '💻', desc: 'Dev tools, IDEs, VMs' },
  { label: 'Gaming',         icon: '🎮', desc: 'AAA games, streaming' },
  { label: 'School',         icon: '📚', desc: 'Notes, assignments, video calls' },
  { label: 'Business',       icon: '💼', desc: 'Spreadsheets, presentations' },
  { label: 'Design',         icon: '🎨', desc: 'Figma, Photoshop, 3D' },
  { label: 'Video Editing',  icon: '🎬', desc: 'Premiere, DaVinci, After Effects' },
];

// ─── Step indicator ──────────────────────────────────────────
function StepIndicator({ step }: { step: 1 | 2 | 3 }) {
  return (
    <div className="flex items-center gap-2 justify-center mb-8">
      {[1, 2, 3].map(n => (
        <div key={n} className="flex items-center gap-2">
          <div className={cn(
            'w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-all duration-300',
            n < step  && 'bg-[#1e90ff] text-white',
            n === step && 'bg-gradient-to-r from-[#1e90ff] to-[#00d4ff] text-white shadow-[0_0_16px_rgba(30,144,255,0.5)]',
            n > step  && 'bg-white/[0.06] text-nt-text3 border border-white/[0.1]',
          )}>
            {n < step ? '✓' : n}
          </div>
          {n < 3 && (
            <div className={cn('w-12 h-px transition-colors duration-300', n < step ? 'bg-[#1e90ff]' : 'bg-white/[0.12]')} />
          )}
        </div>
      ))}
    </div>
  );
}

// ─── Step 1 — Use case selection ─────────────────────────────
function Step1({ selected, onToggle, onNext }: {
  selected: UseCase[];
  onToggle: (uc: UseCase) => void;
  onNext: () => void;
}) {
  return (
    <m.div key="step1" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }}>
      <h3 className="text-xl font-bold text-nt-text1 text-center mb-2">What will you mainly use it for?</h3>
      <p className="text-nt-text2 text-sm text-center mb-8">Select all that apply</p>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-8">
        {USE_CASES.map(uc => {
          const active = selected.includes(uc.label);
          return (
            <m.button
              key={uc.label}
              onClick={() => onToggle(uc.label)}
              whileHover={{ y: -3 }}
              whileTap={{ scale: 0.97 }}
              className={cn(
                'flex flex-col items-center gap-2 rounded-[18px] p-5 border-2 transition-all duration-200 text-center',
                active
                  ? 'bg-[rgba(30,144,255,0.12)] border-[#1e90ff] shadow-[0_0_20px_rgba(30,144,255,0.2)]'
                  : 'bg-white/[0.03] border-white/[0.08] hover:border-[rgba(30,144,255,0.3)] hover:bg-white/[0.06]',
              )}
            >
              <span className="text-3xl">{uc.icon}</span>
              <span className="font-semibold text-sm text-nt-text1">{uc.label}</span>
              <span className="text-xs text-nt-text3">{uc.desc}</span>
              {active && (
                <span className="w-5 h-5 rounded-full bg-[#1e90ff] text-white text-[10px] flex items-center justify-center font-bold">✓</span>
              )}
            </m.button>
          );
        })}
      </div>

      <div className="text-center">
        <button
          onClick={onNext}
          disabled={selected.length === 0}
          className={cn(
            'inline-flex items-center gap-2 px-8 py-3.5 rounded-[14px] font-bold text-base transition-all duration-200',
            selected.length > 0
              ? 'bg-gradient-to-r from-[#1e90ff] to-[#00d4ff] text-white hover:shadow-[0_8px_24px_rgba(30,144,255,0.4)]'
              : 'bg-white/[0.06] text-nt-text3 cursor-not-allowed',
          )}
        >
          Next <ArrowRight size={16} />
        </button>
      </div>
    </m.div>
  );
}

// ─── Step 2 — Budget slider ──────────────────────────────────
function Step2({ budget, onBudget, onBack, onNext }: {
  budget: number;
  onBudget: (v: number) => void;
  onBack: () => void;
  onNext: () => void;
}) {
  return (
    <m.div key="step2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
      <h3 className="text-xl font-bold text-nt-text1 text-center mb-2">What's your budget?</h3>
      <p className="text-nt-text2 text-sm text-center mb-10">We'll find the best laptop in your range</p>

      <div className="max-w-md mx-auto mb-10">
        <div className="flex justify-between text-xs text-nt-text3 mb-3">
          <span>KES 30,000</span>
          <span>KES 350,000+</span>
        </div>
        <input
          type="range"
          min={30000}
          max={350000}
          step={5000}
          value={budget}
          onChange={e => onBudget(Number(e.target.value))}
          className="w-full h-2 rounded-full accent-[#1e90ff] cursor-pointer"
          aria-label="Budget slider"
        />
        <div className="text-center mt-6">
          <span className="text-5xl font-extrabold text-nt-text1">
            KES <span className="text-[#00d4ff]">{budget.toLocaleString()}</span>
          </span>
        </div>

        {/* Budget tier hints */}
        <div className="grid grid-cols-3 gap-3 mt-6">
          {[
            { label: 'Budget',       range: '30K–80K',   min: 30000,  max: 80000 },
            { label: 'Mid-Range',    range: '80K–160K',  min: 80000,  max: 160000 },
            { label: 'Premium',      range: '160K+',     min: 160000, max: 350000 },
          ].map(tier => (
            <button
              key={tier.label}
              onClick={() => onBudget(Math.round((tier.min + tier.max) / 2))}
              className={cn(
                'py-2 px-3 rounded-xl border text-xs font-semibold transition-all',
                budget >= tier.min && budget <= tier.max
                  ? 'bg-[rgba(30,144,255,0.12)] border-[rgba(30,144,255,0.4)] text-[#00d4ff]'
                  : 'bg-white/[0.04] border-white/[0.08] text-nt-text2 hover:border-[rgba(30,144,255,0.25)]',
              )}
            >
              {tier.label}<br /><span className="opacity-60">{tier.range}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="flex gap-3 justify-center">
        <button onClick={onBack} className="flex items-center gap-2 px-5 py-3 rounded-[12px] bg-white/[0.05] border border-white/[0.1] text-nt-text2 font-medium text-sm hover:text-nt-text1 transition-all">
          <ArrowLeft size={14} /> Back
        </button>
        <button onClick={onNext} className="flex items-center gap-2 bg-gradient-to-r from-[#1e90ff] to-[#00d4ff] text-white px-8 py-3 rounded-[14px] font-bold text-sm hover:shadow-[0_6px_20px_rgba(30,144,255,0.4)] transition-all">
          Find Laptops <ArrowRight size={16} />
        </button>
      </div>
    </m.div>
  );
}

// ─── Step 3 — Results ────────────────────────────────────────
function Step3({ useCases, budget, onReset }: {
  useCases: UseCase[];
  budget: number;
  onReset: () => void;
}) {
  const addToCart = useStore(s => s.addToCart);

  // Get recommended product IDs for the first use case, then filter by budget
  const recommendedIds = useCases.flatMap(uc => FINDER_RECOMMENDATIONS[uc] ?? []);
  const unique = [...new Set(recommendedIds)];
  const results = unique
    .map(id => PRODUCTS.find(p => p.id === id))
    .filter((p): p is NonNullable<typeof p> => !!p && p.price <= budget)
    .slice(0, 4);

  return (
    <m.div key="step3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div>
          <h3 className="text-lg font-bold text-nt-text1">
            Best for {useCases.join(', ')}
          </h3>
          <p className="text-sm text-nt-text3">
            Under KES {budget.toLocaleString()} · {results.length} match{results.length !== 1 ? 'es' : ''}
          </p>
        </div>
        <button onClick={onReset} className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/[0.05] border border-white/[0.1] text-nt-text2 text-sm font-medium hover:text-nt-text1 transition-all">
          <ArrowLeft size={13} /> Start over
        </button>
      </div>

      {results.length === 0 ? (
        <div className="text-center py-12 text-nt-text3">
          <div className="text-4xl mb-4">😅</div>
          <p className="font-medium">No matches under KES {budget.toLocaleString()}.</p>
          <button onClick={onReset} className="mt-4 text-[#00d4ff] text-sm font-semibold hover:underline">
            Try a higher budget
          </button>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 gap-4">
          {results.map((p, i) => (
            <m.div
              key={p.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.08 }}
              className="bg-white/[0.04] border border-white/[0.08] rounded-[18px] p-4 hover:border-[rgba(30,144,255,0.3)] transition-all"
            >
              {i === 0 && (
                <span className="inline-block text-xs font-bold text-[#00d4ff] bg-[rgba(0,212,255,0.1)] border border-[rgba(0,212,255,0.2)] px-2.5 py-0.5 rounded-full mb-3">
                  ⭐ Best Match
                </span>
              )}
              <div className="flex items-start gap-4">
                <div className="text-4xl">{p.icon}</div>
                <div className="flex-1 min-w-0">
                  <p className="text-[10px] font-bold text-[#00d4ff] uppercase tracking-wider mb-0.5">{p.brand}</p>
                  <h4 className="text-sm font-semibold text-nt-text1 leading-snug mb-1 line-clamp-2">{p.name}</h4>
                  <p className="text-xs text-nt-text3 mb-2">{p.shortSpecs}</p>
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold text-nt-text1 text-base">
                      KES <span className="text-[#00d4ff]">{p.price.toLocaleString()}</span>
                    </span>
                    <button
                      onClick={() => { addToCart(p); toast.success('Added to cart!'); }}
                      className="flex items-center gap-1.5 bg-gradient-to-r from-[#1e90ff] to-[#00d4ff] text-white px-3 py-1.5 rounded-[8px] text-xs font-bold hover:shadow-[0_4px_14px_rgba(30,144,255,0.4)] transition-all"
                    >
                      <ShoppingCart size={11} /> Add
                    </button>
                  </div>
                </div>
              </div>
            </m.div>
          ))}
        </div>
      )}
    </m.div>
  );
}

// ─── Main Section ────────────────────────────────────────────
export function AIFinderSection() {
  const ref    = useRef<HTMLElement>(null);
  const inView = useInView(ref, { once: true, margin: '-80px' });

  const {
    finderUseCases, finderBudget, finderStep,
    setFinderUseCases, setFinderBudget, setFinderStep, resetFinder,
  } = useStore(s => ({
    finderUseCases: s.finderUseCases,
    finderBudget:   s.finderBudget,
    finderStep:     s.finderStep,
    setFinderUseCases: s.setFinderUseCases,
    setFinderBudget:   s.setFinderBudget,
    setFinderStep:     s.setFinderStep,
    resetFinder:       s.resetFinder,
  }));

  const toggleUseCase = (uc: UseCase) => {
    setFinderUseCases(
      finderUseCases.includes(uc)
        ? finderUseCases.filter(u => u !== uc)
        : [...finderUseCases, uc],
    );
  };

  return (
    <section ref={ref} id="finder" className="py-20 px-6 bg-[#0d1117] relative overflow-hidden">
      {/* bg decoration */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] rounded-full opacity-[0.04] pointer-events-none"
           style={{ background: 'radial-gradient(circle, #7c3aed, transparent)' }} aria-hidden="true" />

      <div className="max-w-[780px] mx-auto">
        {/* Header */}
        <m.div
          initial={{ opacity: 0, y: 24 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 bg-[rgba(124,58,237,0.1)] border border-[rgba(124,58,237,0.25)] rounded-full px-4 py-1.5 mb-4">
            <Zap size={13} className="text-[#a78bfa]" />
            <span className="text-xs font-bold text-[#a78bfa] tracking-wide">AI-Powered</span>
          </div>
          <p className="section-eyebrow mb-3">AI Laptop Finder</p>
          <h2 className="font-display font-bold text-nt-text1 mb-4" style={{ fontSize: 'clamp(1.75rem,3vw,2.5rem)' }}>
            Find Your Perfect Laptop
          </h2>
          <p className="text-nt-text2 max-w-md mx-auto">
            Answer two quick questions and we'll match you with the ideal laptop for your needs and budget.
          </p>
        </m.div>

        {/* Wizard card */}
        <m.div
          initial={{ opacity: 0, y: 24 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.15 }}
          className="bg-white/[0.03] border border-white/[0.08] rounded-[24px] p-6 sm:p-10"
        >
          <StepIndicator step={finderStep} />

          <AnimatePresence mode="wait">
            {finderStep === 1 && (
              <Step1
                key="s1"
                selected={finderUseCases}
                onToggle={toggleUseCase}
                onNext={() => setFinderStep(2)}
              />
            )}
            {finderStep === 2 && (
              <Step2
                key="s2"
                budget={finderBudget}
                onBudget={setFinderBudget}
                onBack={() => setFinderStep(1)}
                onNext={() => setFinderStep(3)}
              />
            )}
            {finderStep === 3 && (
              <Step3
                key="s3"
                useCases={finderUseCases}
                budget={finderBudget}
                onReset={resetFinder}
              />
            )}
          </AnimatePresence>
        </m.div>
      </div>
    </section>
  );
}
