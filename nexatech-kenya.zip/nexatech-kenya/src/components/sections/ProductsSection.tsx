'use client';

import { useRef } from 'react';
import { m, useInView, AnimatePresence } from 'framer-motion';
import { X, ShoppingCart, Star, GitCompare } from 'lucide-react';
import { PRODUCTS } from '@/data';
import { ProductCard } from '@/components/products/ProductCard';
import { useStore } from '@/store';
import { formatKES, starArray, cn } from '@/lib/utils';
import toast from 'react-hot-toast';

const TABS = [
  { id: 'all',        label: 'All' },
  { id: 'laptops',    label: 'Laptops' },
  { id: 'gaming',     label: 'Gaming' },
  { id: 'monitors',   label: 'Monitors' },
  { id: 'accessories',label: 'Accessories' },
  { id: 'networking', label: 'Networking' },
  { id: 'printers',   label: 'Printers' },
];

// ─── Quick View Modal ────────────────────────────────────────
function QuickViewModal() {
  const { isModalOpen, modalProductId, closeModal, addToCart } = useStore(s => ({
    isModalOpen:    s.isModalOpen,
    modalProductId: s.modalProductId,
    closeModal:     s.closeModal,
    addToCart:      s.addToCart,
  }));

  const product = PRODUCTS.find(p => p.id === modalProductId);
  if (!product) return null;

  const stars    = starArray(product.rating);
  const discount = product.oldPrice
    ? Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100)
    : 0;

  const handleAdd = () => {
    addToCart(product);
    toast.success(`${product.name} added to cart!`);
    closeModal();
  };

  return (
    <AnimatePresence>
      {isModalOpen && (
        <m.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={closeModal}
          className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/80 backdrop-blur-xl"
        >
          <m.div
            initial={{ opacity: 0, y: 32, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 16, scale: 0.98 }}
            transition={{ duration: 0.35, ease: [0.19, 1, 0.22, 1] }}
            onClick={e => e.stopPropagation()}
            className="bg-[#0d1117] border border-white/[0.1] rounded-[24px] w-full max-w-[680px] max-h-[90vh] overflow-y-auto"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-white/[0.08]">
              <span className="font-semibold text-base text-nt-text1">Quick View</span>
              <button
                onClick={closeModal}
                className="w-9 h-9 rounded-[9px] bg-white/[0.06] border border-white/[0.1] text-nt-text2 hover:text-nt-text1 flex items-center justify-center transition-all"
                aria-label="Close"
              >
                <X size={16} />
              </button>
            </div>

            {/* Body */}
            <div className="grid sm:grid-cols-2 gap-6 p-6">
              {/* Image */}
              <div className="h-56 bg-gradient-to-br from-[#111827] to-[#1a2332] rounded-[16px] flex items-center justify-center text-[5rem]">
                {product.icon}
              </div>

              {/* Info */}
              <div>
                <p className="text-[11px] font-bold uppercase tracking-widest text-[#00d4ff] mb-1">{product.brand}</p>
                <h2 className="text-xl font-bold text-nt-text1 leading-snug mb-3">{product.name}</h2>

                {/* Stars */}
                <div className="flex items-center gap-1 mb-3">
                  {stars.map((s, i) => (
                    <Star key={i} size={14} className={s === 'full' ? 'fill-[#fbbf24] text-[#fbbf24]' : 'text-nt-text3'} />
                  ))}
                  <span className="text-xs text-nt-text3 ml-1">({product.reviewCount} reviews)</span>
                </div>

                {/* Price */}
                <div className="mb-4 flex items-baseline gap-3">
                  <span className="text-2xl font-extrabold text-nt-text1">
                    KES <span className="text-[#00d4ff]">{product.price.toLocaleString()}</span>
                  </span>
                  {product.oldPrice && (
                    <span className="text-sm text-nt-text3 line-through">
                      KES {product.oldPrice.toLocaleString()}
                    </span>
                  )}
                  {discount > 0 && (
                    <span className="text-xs font-bold text-[#ff3366]">-{discount}%</span>
                  )}
                </div>

                {/* Mini specs */}
                <div className="grid grid-cols-2 gap-2 mb-5">
                  {product.specs.slice(0, 4).map(spec => (
                    <div key={spec.label} className="bg-[#111827] rounded-[8px] px-3 py-2">
                      <div className="text-[10px] text-nt-text3 font-semibold mb-0.5">{spec.label}</div>
                      <div className="text-xs text-nt-text1 font-medium leading-snug">{spec.value}</div>
                    </div>
                  ))}
                </div>

                {/* Actions */}
                <div className="flex gap-3">
                  <button
                    onClick={handleAdd}
                    className="flex-1 flex items-center justify-center gap-2 bg-gradient-to-r from-[#1e90ff] to-[#00d4ff] text-white py-3 rounded-[12px] font-bold text-sm hover:shadow-[0_6px_24px_rgba(30,144,255,0.4)] transition-all"
                  >
                    <ShoppingCart size={16} /> Add to Cart
                  </button>
                </div>
              </div>
            </div>

            {/* Full spec list */}
            <div className="px-6 pb-6">
              <p className="text-xs font-bold uppercase tracking-wider text-nt-text3 mb-3">Full Specifications</p>
              <div className="divide-y divide-white/[0.06]">
                {product.specs.map(spec => (
                  <div key={spec.label} className="flex justify-between py-2.5 text-sm">
                    <span className="text-nt-text3 font-medium">{spec.label}</span>
                    <span className="text-nt-text1 text-right max-w-[55%]">{spec.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </m.div>
        </m.div>
      )}
    </AnimatePresence>
  );
}

// ─── Products Section ────────────────────────────────────────
export function ProductsSection() {
  const ref    = useRef<HTMLElement>(null);
  const inView = useInView(ref, { once: true, margin: '-60px' });

  const { activeTab, setActiveProductTab } = useStore(s => ({
    activeTab:          s.activeProductTab,
    setActiveProductTab: s.setActiveProductTab,
  }));

  const filtered = activeTab === 'all'
    ? PRODUCTS
    : PRODUCTS.filter(p => p.category === activeTab);

  return (
    <>
      <section ref={ref} id="products" className="py-20 px-6 bg-[#080a0f]">
        <div className="max-w-[1200px] mx-auto">

          {/* Header */}
          <m.div
            initial={{ opacity: 0, y: 24 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="text-center mb-10"
          >
            <p className="section-eyebrow mb-3">Featured Products</p>
            <h2 className="font-display font-bold text-nt-text1" style={{ fontSize: 'clamp(1.75rem,3vw,2.5rem)' }}>
              Top Picks This Week
            </h2>
          </m.div>

          {/* Tabs */}
          <m.div
            initial={{ opacity: 0, y: 12 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.5, delay: 0.15 }}
            className="flex flex-wrap gap-2 justify-center mb-10"
            role="tablist"
            aria-label="Product category tabs"
          >
            {TABS.map(tab => (
              <button
                key={tab.id}
                role="tab"
                aria-selected={activeTab === tab.id}
                onClick={() => setActiveProductTab(tab.id)}
                className={cn(
                  'px-4 py-2 rounded-full text-sm font-medium transition-all duration-200',
                  activeTab === tab.id
                    ? 'bg-[rgba(30,144,255,0.18)] border border-[rgba(30,144,255,0.45)] text-[#00d4ff]'
                    : 'bg-white/[0.04] border border-white/[0.08] text-nt-text2 hover:border-[rgba(30,144,255,0.25)] hover:text-[#00d4ff]',
                )}
              >
                {tab.label}
              </button>
            ))}
          </m.div>

          {/* Grid */}
          <AnimatePresence mode="wait">
            <m.div
              key={activeTab}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.35 }}
              className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5"
            >
              {filtered.map((product, i) => (
                <ProductCard key={product.id} product={product} index={i} />
              ))}
            </m.div>
          </AnimatePresence>

          {filtered.length === 0 && (
            <div className="text-center py-20 text-nt-text3">
              <div className="text-5xl mb-4">🔍</div>
              <p className="text-lg font-medium">No products in this category yet.</p>
            </div>
          )}
        </div>
      </section>

      <QuickViewModal />
    </>
  );
}
