'use client';

import { m } from 'framer-motion';
import { Tag, ArrowRight } from 'lucide-react';

export function PromoBanner() {
  return (
    <div className="relative overflow-hidden border-y border-white/[0.06]"
         style={{ background: 'linear-gradient(135deg, #0a1628 0%, #0d1117 50%, #111827 100%)' }}>
      {/* Decorative glow */}
      <div className="absolute inset-0 pointer-events-none" aria-hidden="true"
           style={{ background: 'radial-gradient(ellipse at 30% 50%, rgba(30,144,255,0.07), transparent)' }} />

      <div className="max-w-[1200px] mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-[1fr_auto] items-center gap-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Tag size={14} className="text-[#00d4ff]" />
              <span className="section-eyebrow">Limited Time Offer</span>
            </div>
            <m.h2
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="font-display font-bold text-nt-text1 mb-2"
              style={{ fontSize: 'clamp(1.4rem,2.5vw,1.9rem)' }}
            >
              Get{' '}
              <span style={{ color: '#00d4ff' }}>15% off</span>
              {' '}your first order
            </m.h2>
            <m.p
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-nt-text2 text-sm"
            >
              Use code{' '}
              <code className="text-[#00d4ff] bg-[rgba(0,212,255,0.1)] border border-[rgba(0,212,255,0.2)] px-2 py-0.5 rounded-[6px] font-bold text-sm">
                NEXAKENYA15
              </code>
              {' '}at checkout · Free delivery within Nairobi CBD
            </m.p>
          </div>

          <m.button
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.15 }}
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' })}
            className="flex items-center gap-2 bg-gradient-to-r from-[#1e90ff] to-[#00d4ff] text-white px-7 py-3.5 rounded-[14px] font-bold text-sm whitespace-nowrap hover:shadow-[0_8px_28px_rgba(30,144,255,0.4)] transition-shadow"
          >
            Claim Offer <ArrowRight size={16} />
          </m.button>
        </div>
      </div>
    </div>
  );
}
