'use client';

import { useRef } from 'react';
import { m, useInView, AnimatePresence } from 'framer-motion';
import { Plus, X, Star } from 'lucide-react';
import { COMPARE_PRODUCTS, COMPARE_SPECS, BEST_VALUES } from '@/data';
import { useStore } from '@/store';
import { cn } from '@/lib/utils';
import toast from 'react-hot-toast';

const QUICK_ADD = ['MacBook Pro M3', 'Dell XPS 15', 'ROG Zephyrus G16'];

export function ComparisonSection() {
  const ref    = useRef<HTMLElement>(null);
  const inView = useInView(ref, { once: true, margin: '-80px' });

  const { compareNames, addToCompare, removeFromCompare, clearCompare } = useStore(s => ({
    compareNames:      s.compareNames,
    addToCompare:      s.addToCompare,
    removeFromCompare: s.removeFromCompare,
    clearCompare:      s.clearCompare,
  }));

  const handleAdd = (name: string) => {
    if (compareNames.includes(name)) { toast('Already added', { icon: 'ℹ️' }); return; }
    addToCompare(name);
    toast.success(`${name} added to comparison`);
  };

  // Build cols: spec label col + up to 3 product cols + empty placeholders
  const slots = [
    ...compareNames.map(name => COMPARE_PRODUCTS[name]).filter(Boolean),
    ...Array(Math.max(0, 3 - compareNames.length)).fill(null),
  ];

  return (
    <section ref={ref} id="comparison" className="py-20 px-6 bg-[#080a0f]">
      <div className="max-w-[1100px] mx-auto">

        {/* Header */}
        <m.div
          initial={{ opacity: 0, y: 24 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-10"
        >
          <p className="section-eyebrow mb-3">Compare Products</p>
          <h2 className="font-display font-bold text-nt-text1 mb-4" style={{ fontSize: 'clamp(1.75rem,3vw,2.5rem)' }}>
            Side-by-Side Comparison
          </h2>
          <p className="text-nt-text2 max-w-md mx-auto">
            Compare up to 3 laptops spec-by-spec to find your perfect match.
          </p>
        </m.div>

        {/* Quick-add chips */}
        <m.div
          initial={{ opacity: 0, y: 12 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.15 }}
          className="flex flex-wrap gap-2 justify-center mb-8"
        >
          <span className="text-sm text-nt-text3 self-center">Quick add:</span>
          {QUICK_ADD.map(name => (
            <button
              key={name}
              onClick={() => handleAdd(name)}
              className={cn(
                'flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-medium border transition-all duration-200',
                compareNames.includes(name)
                  ? 'bg-[rgba(30,144,255,0.12)] border-[rgba(30,144,255,0.4)] text-[#00d4ff]'
                  : 'bg-white/[0.04] border-white/[0.08] text-nt-text2 hover:border-[rgba(30,144,255,0.3)] hover:text-[#00d4ff]',
              )}
            >
              <Plus size={13} /> {name}
            </button>
          ))}
          {compareNames.length > 0 && (
            <button
              onClick={() => { clearCompare(); toast('Comparison cleared', { icon: '🗑️' }); }}
              className="flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-medium border border-[rgba(255,51,102,0.25)] text-[#ff3366] bg-[rgba(255,51,102,0.06)] hover:bg-[rgba(255,51,102,0.1)] transition-all"
            >
              <X size={13} /> Clear
            </button>
          )}
        </m.div>

        {/* Comparison table */}
        <m.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.25 }}
          className="overflow-x-auto rounded-[20px] border border-white/[0.08]"
        >
          <table className="w-full min-w-[560px] border-collapse">
            <thead>
              <tr>
                {/* Spec label header */}
                <th className="w-[160px] bg-[#111827] px-5 py-5 text-left">
                  <span className="text-xs font-bold uppercase tracking-wider text-nt-text3">Spec</span>
                </th>

                {/* Product headers */}
                {slots.map((product, i) => (
                  <th key={i} className="bg-[#0d1117] px-4 py-5 text-center border-l border-white/[0.06]">
                    <AnimatePresence mode="wait">
                      {product ? (
                        <m.div
                          key={product.name}
                          initial={{ opacity: 0, y: 8 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -8 }}
                          className="flex flex-col items-center gap-2"
                        >
                          <div className="relative">
                            <span className="text-4xl">{product.icon}</span>
                            <button
                              onClick={() => removeFromCompare(
                                Object.keys(COMPARE_PRODUCTS).find(k => COMPARE_PRODUCTS[k].name === product.name) ?? ''
                              )}
                              className="absolute -top-2 -right-2 w-5 h-5 rounded-full bg-[rgba(255,51,102,0.15)] border border-[rgba(255,51,102,0.3)] text-[#ff3366] flex items-center justify-center hover:bg-[rgba(255,51,102,0.25)] transition-all"
                              aria-label={`Remove ${product.name}`}
                            >
                              <X size={10} />
                            </button>
                          </div>
                          <div className="text-sm font-semibold text-nt-text1 text-center leading-snug">{product.name}</div>
                          <div className="text-base font-extrabold text-[#00d4ff]">{product.price}</div>
                        </m.div>
                      ) : (
                        <m.div
                          key="empty"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="flex flex-col items-center gap-2 py-4 opacity-30"
                        >
                          <div className="w-10 h-10 rounded-full border-2 border-dashed border-nt-text3 flex items-center justify-center">
                            <Plus size={16} className="text-nt-text3" />
                          </div>
                          <span className="text-xs text-nt-text3">Add product</span>
                        </m.div>
                      )}
                    </AnimatePresence>
                  </th>
                ))}
              </tr>
            </thead>

            <tbody>
              {COMPARE_SPECS.map((spec, si) => (
                <m.tr
                  key={spec.key}
                  initial={{ opacity: 0, x: -10 }}
                  animate={inView ? { opacity: 1, x: 0 } : {}}
                  transition={{ delay: 0.35 + si * 0.05 }}
                  className="border-t border-white/[0.06] hover:bg-white/[0.015] transition-colors"
                >
                  {/* Spec label */}
                  <td className="bg-[#111827] px-5 py-4">
                    <span className="text-sm font-semibold text-nt-text3">{spec.label}</span>
                  </td>

                  {/* Values */}
                  {slots.map((product, ci) => {
                    const val     = product?.specs[spec.key];
                    const isBest  = val && BEST_VALUES[spec.key] === val;
                    return (
                      <td
                        key={ci}
                        className={cn(
                          'px-4 py-4 text-sm text-center border-l border-white/[0.06] bg-[#0d1117]',
                          isBest ? 'text-[#00d4ff] font-bold' : 'text-nt-text1',
                        )}
                      >
                        <AnimatePresence mode="wait">
                          {val ? (
                            <m.span
                              key={val}
                              initial={{ opacity: 0 }}
                              animate={{ opacity: 1 }}
                              className="flex flex-col items-center gap-1"
                            >
                              {val}
                              {isBest && (
                                <span className="text-[10px] font-bold text-[#00d4ff] bg-[rgba(0,212,255,0.08)] px-1.5 py-0.5 rounded-full">
                                  ★ Best
                                </span>
                              )}
                            </m.span>
                          ) : (
                            <m.span key="dash" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-nt-text3 opacity-30">—</m.span>
                          )}
                        </AnimatePresence>
                      </td>
                    );
                  })}
                </m.tr>
              ))}

              {/* Buy row */}
              <tr className="border-t border-white/[0.08]">
                <td className="bg-[#111827] px-5 py-4 text-sm font-semibold text-nt-text3">Action</td>
                {slots.map((product, i) => (
                  <td key={i} className="px-4 py-4 text-center border-l border-white/[0.06] bg-[#0d1117]">
                    {product ? (
                      <button
                        onClick={() => {
                          const p = Object.values(COMPARE_PRODUCTS).find(c => c.name === product.name);
                          if (p) toast.success(`Added ${p.name} to cart!`);
                        }}
                        className="inline-flex items-center gap-1.5 bg-gradient-to-r from-[#1e90ff] to-[#00d4ff] text-white text-xs font-bold px-4 py-2 rounded-[9px] hover:shadow-[0_4px_16px_rgba(30,144,255,0.35)] transition-all"
                      >
                        Buy Now
                      </button>
                    ) : (
                      <span className="text-nt-text3 opacity-20 text-sm">—</span>
                    )}
                  </td>
                ))}
              </tr>
            </tbody>
          </table>
        </m.div>
      </div>
    </section>
  );
}
