'use client';

import { useRef } from 'react';
import { m, useInView } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { CATEGORIES } from '@/data';
import { useStore } from '@/store';

const container = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.07, delayChildren: 0.15 } },
};
const item = {
  hidden:  { opacity: 0, y: 28, scale: 0.96 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.55, ease: [0.19,1,0.22,1] } },
};

export function CategoriesSection() {
  const ref    = useRef<HTMLElement>(null);
  const inView = useInView(ref, { once: true, margin: '-80px' });
  const { setActiveProductTab } = useStore(s => ({ setActiveProductTab: s.setActiveProductTab }));

  const handleClick = (id: string) => {
    setActiveProductTab(id);
    document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section ref={ref} id="categories" className="py-20 px-6 bg-[#0d1117]">
      <div className="max-w-[1200px] mx-auto">

        {/* Header */}
        <m.div
          initial={{ opacity: 0, y: 24 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <p className="section-eyebrow mb-3">Shop by Category</p>
          <h2 className="font-display font-bold text-nt-text1 mb-4"
              style={{ fontSize: 'clamp(1.75rem,3vw,2.5rem)' }}>
            Everything Tech, One Place
          </h2>
          <p className="text-nt-text2 text-base max-w-md mx-auto leading-relaxed">
            From budget ultrabooks to professional workstations — find your perfect setup.
          </p>
        </m.div>

        {/* Grid */}
        <m.div
          variants={container}
          initial="hidden"
          animate={inView ? 'visible' : 'hidden'}
          className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-7 gap-4"
        >
          {CATEGORIES.map(cat => (
            <m.button
              key={cat.id}
              variants={item}
              onClick={() => handleClick(cat.id)}
              whileHover={{ y: -6, transition: { duration: 0.25 } }}
              whileTap={{ scale: 0.97 }}
              className="group relative flex flex-col items-center gap-3 bg-white/[0.04] border border-white/[0.08] rounded-[18px] px-4 py-5 text-center cursor-pointer transition-colors duration-200 hover:bg-white/[0.07] hover:border-[rgba(30,144,255,0.3)] overflow-hidden"
            >
              {/* Glow on hover */}
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
                   style={{ background: 'radial-gradient(ellipse at 50% 100%, rgba(30,144,255,0.1), transparent 70%)' }}
                   aria-hidden="true" />

              {/* Icon container */}
              <div className="w-14 h-14 rounded-[14px] flex items-center justify-center text-3xl transition-all duration-300 bg-gradient-to-br from-[rgba(30,144,255,0.12)] to-[rgba(0,212,255,0.07)] group-hover:from-[rgba(30,144,255,0.25)] group-hover:to-[rgba(0,212,255,0.15)] group-hover:scale-110">
                {cat.icon}
              </div>

              <div>
                <div className="text-sm font-semibold text-nt-text1 leading-tight">{cat.name}</div>
                <div className="text-xs text-nt-text3 mt-0.5">{cat.count} items</div>
              </div>

              {/* Arrow appears on hover */}
              <div className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                <ArrowRight size={12} className="text-[#00d4ff]" />
              </div>
            </m.button>
          ))}
        </m.div>

        {/* View all link */}
        <m.div
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : {}}
          transition={{ delay: 0.6 }}
          className="text-center mt-8"
        >
          <button
            onClick={() => document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' })}
            className="inline-flex items-center gap-2 text-sm text-[#00d4ff] font-semibold hover:gap-3 transition-all duration-200"
          >
            View all products <ArrowRight size={14} />
          </button>
        </m.div>
      </div>
    </section>
  );
}
