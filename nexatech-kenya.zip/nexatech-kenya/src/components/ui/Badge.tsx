import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '@/lib/utils';

const badgeVariants = cva(
  'inline-flex items-center gap-1 font-bold rounded-[6px] px-2 py-0.5 text-[11px] leading-none',
  {
    variants: {
      variant: {
        new:      'badge-new',
        hot:      'badge-hot',
        sale:     'badge-sale',
        limited:  'badge-limited',
        default:  'bg-white/[0.08] text-nt-text2 border border-white/[0.1]',
        cyan:     'bg-[rgba(0,212,255,0.1)] text-[#00d4ff] border border-[rgba(0,212,255,0.25)]',
        blue:     'bg-[rgba(30,144,255,0.1)] text-[#1e90ff] border border-[rgba(30,144,255,0.25)]',
        purple:   'bg-[rgba(124,58,237,0.1)] text-[#a78bfa] border border-[rgba(124,58,237,0.25)]',
        verified: 'bg-[rgba(57,255,20,0.08)] text-[#39ff14] border border-[rgba(57,255,20,0.2)]',
      },
    },
    defaultVariants: { variant: 'default' },
  },
);

export interface BadgeProps
  extends React.HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof badgeVariants> {}

export function Badge({ className, variant, ...props }: BadgeProps) {
  return <span className={cn(badgeVariants({ variant }), className)} {...props} />;
}
