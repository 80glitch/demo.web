'use client';

import { useRef } from 'react';
import { m, useInView } from 'framer-motion';
import { cn } from '@/lib/utils';

interface SectionHeaderProps {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  align?: 'left' | 'center';
  className?: string;
}

export function SectionHeader({ eyebrow, title, subtitle, align = 'center', className }: SectionHeaderProps) {
  return (
    <div className={cn(align === 'center' ? 'text-center' : 'text-left', className)}>
      {eyebrow && <p className="section-eyebrow mb-3">{eyebrow}</p>}
      <h2
        className="font-display font-bold text-nt-text1 mb-4"
        style={{ fontSize: 'clamp(1.75rem,3vw,2.5rem)' }}
      >
        {title}
      </h2>
      {subtitle && (
        <p className={cn('text-nt-text2 text-base leading-relaxed', align === 'center' && 'max-w-md mx-auto')}>
          {subtitle}
        </p>
      )}
    </div>
  );
}

interface RevealProps {
  children: React.ReactNode;
  delay?: number;
  className?: string;
  as?: keyof JSX.IntrinsicElements;
}

export function Reveal({ children, delay = 0, className, as = 'div' }: RevealProps) {
  const ref    = useRef<HTMLDivElement>(null);
  const inView = useInView(ref as React.RefObject<Element>, { once: true, margin: '-60px' });

  const Tag = m[as as keyof typeof m] as typeof m.div;

  return (
    <Tag
      ref={ref as React.RefObject<HTMLDivElement>}
      initial={{ opacity: 0, y: 24 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay, ease: [0.19, 1, 0.22, 1] }}
      className={className}
    >
      {children}
    </Tag>
  );
}

interface GlassCardProps extends React.HTMLAttributes<HTMLDivElement> {
  hover?: boolean;
  glow?: boolean;
}

export function GlassCard({ className, hover = true, glow = false, children, ...props }: GlassCardProps) {
  return (
    <div
      className={cn(
        'glass-card rounded-[22px] transition-all duration-300',
        hover && 'hover:bg-white/[0.07] hover:border-[rgba(30,144,255,0.3)]',
        glow   && 'hover:shadow-[0_8px_40px_rgba(30,144,255,0.15)]',
        className,
      )}
      {...props}
    >
      {children}
    </div>
  );
}
