'use client';

import { forwardRef } from 'react';
import { m } from 'framer-motion';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '@/lib/utils';

const buttonVariants = cva(
  // base
  'inline-flex items-center justify-center gap-2 font-semibold transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#1e90ff] disabled:pointer-events-none disabled:opacity-40 select-none',
  {
    variants: {
      variant: {
        primary:   'bg-gradient-to-r from-[#1e90ff] to-[#00d4ff] text-white hover:shadow-[0_8px_28px_rgba(30,144,255,0.4)] hover:-translate-y-0.5',
        secondary: 'bg-white/[0.05] border border-[rgba(30,144,255,0.35)] text-[#00d4ff] backdrop-blur-md hover:bg-[rgba(30,144,255,0.1)] hover:-translate-y-0.5',
        ghost:     'bg-white/[0.04] border border-white/[0.08] text-nt-text2 hover:bg-white/[0.08] hover:text-nt-text1 hover:border-[rgba(30,144,255,0.25)]',
        danger:    'bg-[rgba(255,51,102,0.12)] border border-[rgba(255,51,102,0.3)] text-[#ff3366] hover:bg-[rgba(255,51,102,0.2)]',
        neon:      'bg-[rgba(57,255,20,0.1)] border border-[rgba(57,255,20,0.25)] text-[#39ff14] hover:bg-[rgba(57,255,20,0.18)]',
        unstyled:  '',
      },
      size: {
        xs:  'h-7  px-3   text-xs  rounded-[8px]',
        sm:  'h-9  px-4   text-sm  rounded-[10px]',
        md:  'h-11 px-6   text-sm  rounded-[12px]',
        lg:  'h-13 px-8   text-base rounded-[14px]',
        xl:  'h-14 px-10  text-base rounded-[16px]',
        icon:'h-10 w-10          rounded-[10px]',
      },
    },
    defaultVariants: {
      variant: 'primary',
      size:    'md',
    },
  },
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  loading?: boolean;
  icon?: React.ReactNode;
  iconRight?: React.ReactNode;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, loading, icon, iconRight, children, disabled, ...props }, ref) => {
    return (
      <button
        ref={ref}
        disabled={disabled || loading}
        className={cn(buttonVariants({ variant, size }), className)}
        {...props}
      >
        {loading ? (
          <m.span
            animate={{ rotate: 360 }}
            transition={{ repeat: Infinity, duration: 0.7, ease: 'linear' }}
            className="w-4 h-4 border-2 border-current border-t-transparent rounded-full"
          />
        ) : icon}
        {children}
        {!loading && iconRight}
      </button>
    );
  },
);

Button.displayName = 'Button';
