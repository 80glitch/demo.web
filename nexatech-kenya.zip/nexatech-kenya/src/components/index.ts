// UI primitives
export { Button }              from './ui/Button';
export { Badge }               from './ui/Badge';
export { Skeleton, ProductCardSkeleton, ReviewCardSkeleton } from './ui/Skeleton';
export { SectionHeader, Reveal, GlassCard } from './ui/Section';

// Layout
export { Navbar }    from './layout/Navbar';
export { Footer }    from './layout/Footer';
export { Providers } from './layout/Providers';

// Sections
export { HeroSection }       from './sections/HeroSection';
export { TrustedBrands }     from './sections/TrustedBrands';
export { CategoriesSection } from './sections/CategoriesSection';
export { PromoBanner }       from './sections/PromoBanner';
export { ProductsSection }   from './sections/ProductsSection';
export { AIFinderSection }   from './sections/AIFinderSection';
export { ComparisonSection } from './sections/ComparisonSection';
export { BuildSetupSection } from './sections/BuildSetupSection';
export { ReviewsSection }    from './sections/ReviewsSection';
export { CheckoutSection }   from './sections/CheckoutSection';

// Products
export { ProductCard } from './products/ProductCard';
