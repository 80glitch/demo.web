'use client';

import { useState } from 'react';
import { m } from 'framer-motion';
import { ArrowRight, Mail, Phone, MapPin, Instagram, Twitter, Linkedin, Youtube } from 'lucide-react';
import toast from 'react-hot-toast';

const FOOTER_LINKS = {
  Shop: ['Laptops', 'Gaming', 'Monitors', 'Accessories', 'Networking', 'Printers', 'Components'],
  Support: ['Track Order', 'Returns & Refunds', 'Warranty Claims', 'FAQ', 'WhatsApp Chat', 'Email Support'],
  Company: ['About Us', 'Careers', 'Press Room', 'Blog', 'Partner With Us', 'Bulk Orders'],
  Legal: ['Privacy Policy', 'Terms of Service', 'Cookie Policy', 'VAT Information'],
};

const BRANDS = ['Apple', 'Dell', 'HP', 'Lenovo', 'ASUS', 'Samsung', 'LG', 'Logitech', 'MSI', 'Razer', 'Ubiquiti', 'Epson'];

export function Footer() {
  const [email, setEmail] = useState('');

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    toast.success('Subscribed! You\'ll get the best deals first.');
    setEmail('');
  };

  return (
    <footer className="bg-[#0d1117] border-t border-white/[0.07]">

      {/* Newsletter strip */}
      <div className="border-b border-white/[0.06]">
        <div className="max-w-[1200px] mx-auto px-6 py-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div>
              <p className="section-eyebrow mb-2">Newsletter</p>
              <h3 className="font-display font-bold text-xl text-nt-text1 mb-2">
                Get deals before anyone else
              </h3>
              <p className="text-sm text-nt-text2">
                Weekly deals, new arrivals, and exclusive discounts straight to your inbox.
                No spam — unsubscribe anytime.
              </p>
            </div>
            <form onSubmit={handleSubscribe} className="flex gap-3 sm:max-w-md lg:ml-auto w-full">
              <div className="relative flex-1">
                <Mail size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-nt-text3" />
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  className="nt-input pl-10 h-full"
                  required
                />
              </div>
              <button
                type="submit"
                className="flex items-center gap-2 bg-gradient-to-r from-[#1e90ff] to-[#00d4ff] text-white px-5 py-3 rounded-[12px] font-bold text-sm whitespace-nowrap hover:shadow-[0_6px_20px_rgba(30,144,255,0.4)] transition-all"
              >
                Subscribe <ArrowRight size={14} />
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* Brand logos strip */}
      <div className="border-b border-white/[0.05]">
        <div className="max-w-[1200px] mx-auto px-6 py-5">
          <div className="flex items-center gap-6 overflow-x-auto no-scrollbar">
            <span className="text-xs font-bold uppercase tracking-wider text-nt-text3 whitespace-nowrap flex-shrink-0">
              Authorised for:
            </span>
            {BRANDS.map(brand => (
              <span key={brand} className="text-sm font-bold text-nt-text3 opacity-50 hover:opacity-80 transition-opacity cursor-default whitespace-nowrap">
                {brand}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Main footer grid */}
      <div className="max-w-[1200px] mx-auto px-6 py-14">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-[2fr_1fr_1fr_1fr_1fr] gap-10">

          {/* Brand col */}
          <div className="col-span-2 md:col-span-3 lg:col-span-1">
            {/* Logo */}
            <div className="flex items-center gap-3 mb-4">
              <div className="w-9 h-9 rounded-[10px] bg-gradient-to-br from-[#1e90ff] to-[#00d4ff] flex items-center justify-center font-black text-white text-sm">
                N
              </div>
              <span className="font-display font-bold text-xl text-nt-text1">
                Nexa<span className="text-[#00d4ff]">Tech</span> Kenya
              </span>
            </div>

            <p className="text-sm text-nt-text3 leading-relaxed mb-5 max-w-[260px]">
              Kenya's premium electronics marketplace. Authorised dealer for 50+ global brands.
              Serving customers since 2020.
            </p>

            {/* Contact */}
            <div className="flex flex-col gap-2.5 mb-6">
              {[
                { icon: <MapPin size={13} />,  text: 'Gateway Mall, Mombasa Road, Nairobi' },
                { icon: <Phone size={13} />,   text: '0800 NEXATECH (Free)'                },
                { icon: <Mail size={13} />,    text: 'hello@nexatech.co.ke'                },
              ].map(({ icon, text }) => (
                <div key={text} className="flex items-start gap-2 text-xs text-nt-text3">
                  <span className="text-[#1e90ff] mt-0.5 flex-shrink-0">{icon}</span>
                  {text}
                </div>
              ))}
            </div>

            {/* Social */}
            <div className="flex gap-2.5">
              {[
                { icon: <Twitter size={15} />,   label: 'Twitter'   },
                { icon: <Instagram size={15} />, label: 'Instagram' },
                { icon: <Linkedin size={15} />,  label: 'LinkedIn'  },
                { icon: <Youtube size={15} />,   label: 'YouTube'   },
              ].map(s => (
                <button
                  key={s.label}
                  aria-label={s.label}
                  className="w-9 h-9 rounded-[9px] bg-white/[0.05] border border-white/[0.08] text-nt-text3 hover:text-[#00d4ff] hover:border-[rgba(30,144,255,0.3)] hover:bg-white/[0.08] flex items-center justify-center transition-all duration-200"
                >
                  {s.icon}
                </button>
              ))}
            </div>
          </div>

          {/* Link cols */}
          {Object.entries(FOOTER_LINKS).map(([heading, links]) => (
            <div key={heading}>
              <p className="text-xs font-bold uppercase tracking-wider text-nt-text1 mb-4">{heading}</p>
              <ul className="flex flex-col gap-2.5">
                {links.map(link => (
                  <li key={link}>
                    <a
                      href="#"
                      onClick={e => e.preventDefault()}
                      className="text-sm text-nt-text3 hover:text-[#00d4ff] transition-colors duration-150"
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-white/[0.06]">
        <div className="max-w-[1200px] mx-auto px-6 py-5 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-nt-text3">
          <p>© 2025 NexaTech Kenya Ltd. All rights reserved. Registered in Kenya · VAT PIN: P051234567L</p>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-[#39ff14] inline-block animate-pulse" />
              All systems operational
            </span>
            <span>Made with ❤️ in Nairobi</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
