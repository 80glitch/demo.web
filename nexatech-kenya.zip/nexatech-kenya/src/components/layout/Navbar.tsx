'use client';

import { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { m, AnimatePresence } from 'framer-motion';
import { ShoppingCart, Search, Heart, Menu, X, Zap } from 'lucide-react';
import { useStore } from '@/store';
import { formatKES } from '@/lib/utils';
import { NAV_LINKS } from '@/data';
import { cn } from '@/lib/utils';

export function Navbar() {
  const [scrolled, setScrolled]     = useState(false);
  const [menuOpen, setMenuOpen]     = useState(false);
  const [cartPop, setCartPop]       = useState(false);
  const prevCount                   = useRef(0);

  const { cartCount, cartGrandTotal, wishlistIds, openModal } = useStore(s => ({
    cartCount:     s.cartCount(),
    cartGrandTotal: s.cartGrandTotal(),
    wishlistIds:   s.wishlistIds,
    openModal:     s.openModal,
  }));

  // Scroll detection
  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 60);
    window.addEventListener('scroll', handler, { passive: true });
    return () => window.removeEventListener('scroll', handler);
  }, []);

  // Cart badge bounce
  useEffect(() => {
    if (cartCount > prevCount.current) {
      setCartPop(true);
      setTimeout(() => setCartPop(false), 400);
    }
    prevCount.current = cartCount;
  }, [cartCount]);

  const scrollToSection = (href: string) => {
    const id = href.replace('#', '');
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    setMenuOpen(false);
  };

  return (
    <>
      <m.nav
        initial={{ y: -80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6, ease: [0.19, 1, 0.22, 1] }}
        className={cn(
          'fixed top-0 left-0 right-0 z-[100] px-6 py-4',
          'flex items-center justify-between',
          'transition-all duration-300',
          scrolled
            ? 'bg-[#080a0f]/97 shadow-[0_1px_0_rgba(255,255,255,0.06)]'
            : 'bg-[#080a0f]/85',
          'backdrop-blur-xl border-b border-white/[0.06]',
        )}
      >
        {/* Logo */}
        <Link
          href="/"
          className="flex items-center gap-3 group"
          aria-label="NexaTech Kenya home"
        >
          <div className="w-9 h-9 rounded-[10px] bg-gradient-to-br from-[#1e90ff] to-[#00d4ff] flex items-center justify-center font-black text-white text-sm shadow-[0_0_20px_rgba(30,144,255,0.35)] group-hover:shadow-[0_0_30px_rgba(30,144,255,0.5)] transition-shadow">
            N
          </div>
          <span className="font-display font-bold text-xl text-nt-text1 leading-none">
            Nexa<span className="text-[#00d4ff]">Tech</span>
          </span>
        </Link>

        {/* Desktop nav links */}
        <ul className="hidden lg:flex items-center gap-8">
          {NAV_LINKS.map(link => (
            <li key={link.href}>
              <button
                onClick={() => scrollToSection(link.href)}
                className="relative text-sm font-medium text-nt-text2 hover:text-[#00d4ff] transition-colors duration-200 group"
              >
                {link.label}
                {link.badge && (
                  <span className="ml-1.5 text-[10px] font-bold bg-gradient-to-r from-[#1e90ff] to-[#00d4ff] text-white px-1.5 py-0.5 rounded-full">
                    {link.badge}
                  </span>
                )}
                <span className="absolute -bottom-1 left-0 right-0 h-px bg-[#00d4ff] scale-x-0 group-hover:scale-x-100 transition-transform duration-200 origin-left" />
              </button>
            </li>
          ))}
        </ul>

        {/* Right actions */}
        <div className="flex items-center gap-2">
          {/* Search */}
          <button
            className="hidden sm:flex w-10 h-10 rounded-xl bg-white/[0.04] border border-white/[0.08] text-nt-text2 hover:text-[#00d4ff] hover:border-[rgba(30,144,255,0.3)] hover:bg-white/[0.08] items-center justify-center transition-all duration-200"
            aria-label="Search"
          >
            <Search size={18} />
          </button>

          {/* Wishlist */}
          <button
            className="hidden sm:flex w-10 h-10 rounded-xl bg-white/[0.04] border border-white/[0.08] text-nt-text2 hover:text-[#ff3366] hover:border-[rgba(255,51,102,0.3)] hover:bg-[rgba(255,51,102,0.06)] items-center justify-center transition-all duration-200 relative"
            aria-label={`Wishlist (${wishlistIds.length} items)`}
          >
            <Heart size={18} />
            {wishlistIds.length > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#ff3366] text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                {wishlistIds.length}
              </span>
            )}
          </button>

          {/* Cart */}
          <button
            onClick={() => document.getElementById('checkout')?.scrollIntoView({ behavior: 'smooth' })}
            className="flex items-center gap-2 bg-gradient-to-r from-[#1e90ff] to-[#00d4ff] text-white px-4 py-2.5 rounded-xl font-semibold text-sm hover:shadow-[0_8px_25px_rgba(30,144,255,0.4)] hover:-translate-y-0.5 transition-all duration-200"
            aria-label={`Cart (${cartCount} items)`}
          >
            <ShoppingCart size={16} />
            <span className="hidden sm:inline">Cart</span>
            <AnimatePresence mode="wait">
              {cartCount > 0 && (
                <m.span
                  key={cartCount}
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  exit={{ scale: 0 }}
                  className={cn(
                    'bg-white/20 text-white text-[11px] font-bold w-5 h-5 rounded-full flex items-center justify-center',
                    cartPop && 'cart-badge-bounce',
                  )}
                >
                  {cartCount}
                </m.span>
              )}
            </AnimatePresence>
          </button>

          {/* Mobile menu toggle */}
          <button
            onClick={() => setMenuOpen(v => !v)}
            className="lg:hidden w-10 h-10 rounded-xl bg-white/[0.04] border border-white/[0.08] text-nt-text2 hover:text-nt-text1 flex items-center justify-center transition-all duration-200"
            aria-label="Toggle menu"
            aria-expanded={menuOpen}
          >
            {menuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </m.nav>

      {/* Floating cart bar */}
      <AnimatePresence>
        {cartCount > 0 && (
          <m.button
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 100, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            onClick={() => document.getElementById('checkout')?.scrollIntoView({ behavior: 'smooth' })}
            className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[150] flex items-center gap-3 bg-gradient-to-r from-[#1e90ff] to-[#00d4ff] text-white px-6 py-3.5 rounded-full font-bold text-sm shadow-[0_8px_32px_rgba(30,144,255,0.45)] hover:-translate-y-0.5 hover:shadow-[0_12px_40px_rgba(30,144,255,0.55)] transition-all duration-200"
          >
            <ShoppingCart size={16} />
            <span>View Cart ({cartCount} items)</span>
            <span className="text-white/80">·</span>
            <span>{formatKES(cartGrandTotal)}</span>
          </m.button>
        )}
      </AnimatePresence>

      {/* Mobile slide-down menu */}
      <AnimatePresence>
        {menuOpen && (
          <m.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: [0.4, 0, 0.2, 1] }}
            className="fixed top-[73px] left-0 right-0 z-[99] bg-[#0d1117]/97 backdrop-blur-xl border-b border-white/[0.08] overflow-hidden"
          >
            <div className="px-6 py-4 flex flex-col gap-2">
              {NAV_LINKS.map((link, i) => (
                <m.button
                  key={link.href}
                  initial={{ x: -20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  transition={{ delay: i * 0.05 }}
                  onClick={() => scrollToSection(link.href)}
                  className="flex items-center justify-between text-left py-3 px-4 rounded-xl text-nt-text1 font-medium hover:bg-white/[0.06] hover:text-[#00d4ff] transition-all duration-150"
                >
                  <span>{link.label}</span>
                  {link.badge && (
                    <span className="text-[10px] font-bold bg-gradient-to-r from-[#1e90ff] to-[#00d4ff] text-white px-2 py-0.5 rounded-full">
                      {link.badge}
                    </span>
                  )}
                </m.button>
              ))}
              <div className="h-px bg-white/[0.06] my-2" />
              <div className="flex gap-3 pb-2">
                <div className="flex-1 text-center py-2 rounded-xl border border-white/[0.08] text-sm text-nt-text2">
                  📍 Nairobi, Kenya
                </div>
                <div className="flex-1 text-center py-2 rounded-xl border border-white/[0.08] text-sm text-nt-text2">
                  📞 0800 NEXATECH
                </div>
              </div>
            </div>
          </m.div>
        )}
      </AnimatePresence>
    </>
  );
}
