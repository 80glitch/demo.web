'use client';

import { useEffect } from 'react';
import { LazyMotion, domAnimation } from 'framer-motion';
import Lenis from 'lenis';
import { Toaster } from 'react-hot-toast';

// ─── Lenis smooth scroll init ────────────────────────────────
function SmoothScroll() {
  useEffect(() => {
    const lenis = new Lenis({
      duration: 1.2,
      easing: (t: number) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      touchMultiplier: 2,
      infinite: false,
    });

    function raf(time: number) {
      lenis.raf(time);
      requestAnimationFrame(raf);
    }
    requestAnimationFrame(raf);

    return () => lenis.destroy();
  }, []);

  return null;
}

// ─── Providers ────────────────────────────────────────────────
export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <LazyMotion features={domAnimation} strict>
      <SmoothScroll />
      {children}
      <Toaster
        position="bottom-right"
        toastOptions={{
          duration: 3000,
          style: {
            background: '#0d1117',
            color: '#f0f4ff',
            border: '1px solid rgba(30,144,255,0.3)',
            borderRadius: '12px',
            padding: '12px 16px',
            fontSize: '0.875rem',
            fontFamily: 'Inter, sans-serif',
            boxShadow: '0 8px 32px rgba(0,0,0,0.4)',
          },
          success: {
            iconTheme: { primary: '#39ff14', secondary: '#080a0f' },
          },
          error: {
            iconTheme: { primary: '#ff3366', secondary: '#080a0f' },
          },
        }}
      />
    </LazyMotion>
  );
}
